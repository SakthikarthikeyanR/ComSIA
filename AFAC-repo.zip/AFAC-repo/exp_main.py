"""Main experiments: baselines, false-alarm control (AFAC and comparators), streams with drift.
Usage: python exp_main.py {nsl|unsw|cic} SEED [SEED ...]
Writes results/main_<dataset>_seed<k>.json
"""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier, MLPRegressor
from xgboost import XGBClassifier
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, load_cic, metrics, group_split
from afac import AFAC, thr_for_far, exceed_curve, em_prior_adjust, GRID

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results"); os.makedirs(OUT, exist_ok=True)
ALPHAS = [0.01, 0.05]
BUDGETS = [0.005, 0.01, 0.02]


def stratified_subsample(fam, n, rng):
    """Sample n indices, proportional per family, keeping all records of families with < 1000 records."""
    idx = []
    tot = len(fam); u, c = np.unique(fam, return_counts=True)
    for f, k in zip(u, c):
        ii = np.where(fam == f)[0]
        take = k if k < 1000 else int(round(n * k / tot))
        idx.append(rng.choice(ii, min(take, k), replace=False))
    return np.sort(np.concatenate(idx))


def drift_order(y, rng, phases=((0.1, 0.3), (0.8, 0.4), (0.3, 0.3))):
    """Re-order the test records into a stream with three phases of different attack share (p, share of stream).
    Records are drawn without replacement; the stream length is limited by the scarcer class."""
    att = rng.permutation(np.where(y == 1)[0]); nor = rng.permutation(np.where(y == 0)[0])
    # maximal total length L such that each phase's demands fit
    need_a = sum(p * f for p, f in phases); need_n = sum((1 - p) * f for p, f in phases)
    L = int(min(len(att) / need_a, len(nor) / need_n))
    order, ia, inn = [], 0, 0
    for p, f in phases:
        m = int(f * L); ka = int(round(p * m)); kn = m - ka
        seg = np.r_[att[ia:ia + ka], nor[inn:inn + kn]]; ia += ka; inn += kn
        order.append(rng.permutation(seg))
    return np.concatenate(order)


def summarize(y, pred, score=None, extra=None):
    m = metrics(y, pred, score)
    if extra is not None:
        for k, mask in extra.items():
            m[k] = float(100 * pred[mask].mean()) if mask.any() else None
    return m


def run(ds, seed):
    t0 = time.time(); rng = np.random.default_rng(seed)
    D = {"nsl": load_nsl, "unsw": load_unsw, "cic": load_cic}[ds]()
    X, y, fam = D.X_tr, D.y_tr, D.fam_tr
    if ds == "cic":
        sub = stratified_subsample(fam, 300000, rng); X, y, fam = X[sub], y[sub], fam[sub]
    i_fit, i_val = group_split(X, y, 0.2, seed)
    Xf, yf, Xv, yv = X[i_fit], y[i_fit], X[i_val], y[i_val]
    Xt, yt = D.X_te, D.y_te
    R = dict(dataset=D.name, seed=seed, n_fit=int(len(i_fit)), n_val=int(len(i_val)), val_attack_share=float(yv.mean()),
             fit_attack_share=float(yf.mean()), test_attack_share=float(yt.mean()), files=D.files)
    # family masks for per-family recall
    fams = [f for f in np.unique(D.fam_te) if f not in ("Normal", "normal", "BENIGN")]
    extra = {f"rec_{f}": (D.fam_te == f) for f in fams}
    if D.unseen_te.any():
        extra["rec_unseen"] = D.unseen_te; extra["rec_seen"] = (yt == 1) & ~D.unseen_te

    # ---------------- detectors ----------------
    models = {
        "LR": LogisticRegression(max_iter=2000),
        "LinearSVM": LinearSVC(C=1.0, max_iter=5000, random_state=seed),
        "KNN": KNeighborsClassifier(n_neighbors=5, n_jobs=2),
        "DT": DecisionTreeClassifier(random_state=seed),
        "RF": RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=2),
        "XGB": XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                             tree_method="hist", n_jobs=2, random_state=seed, eval_metric="logloss"),
        "MLP": MLPClassifier(hidden_layer_sizes=(128, 64), early_stopping=True, max_iter=60, random_state=seed),
    }
    sv, st, timing = {}, {}, {}
    for name, m in models.items():
        a = time.time(); m.fit(Xf, yf); timing[name] = time.time() - a
        if hasattr(m, "predict_proba"):
            sv[name] = m.predict_proba(Xv)[:, 1]; st[name] = m.predict_proba(Xt)[:, 1]
        else:
            sv[name] = m.decision_function(Xv); st[name] = m.decision_function(Xt)
        thr = 0.5 if hasattr(m, "predict_proba") else 0.0
        R.setdefault("baseline", {})[name] = summarize(yt, st[name] > thr, st[name], extra)
        R["baseline"][name]["val"] = metrics(yv, sv[name] > thr, sv[name])
        if ds == "nsl":
            p21 = m.predict_proba(D.X_21)[:, 1] if hasattr(m, "predict_proba") else m.decision_function(D.X_21)
            R["baseline"][name]["test21"] = metrics(D.y_21, p21 > thr, p21)
    # anomaly detectors trained on normal fitting records only
    Xn = Xf[yf == 0]
    a = time.time(); iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(Xn); timing["IF"] = time.time() - a
    av, at = -iso.score_samples(Xv), -iso.score_samples(Xt)
    sub = rng.choice(len(Xn), min(len(Xn), 60000), replace=False)
    a = time.time()
    clip = lambda Z: np.clip(Z, -5, 5)   # standardised inputs clipped to [-5, 5] for the autoencoder
    ae = MLPRegressor(hidden_layer_sizes=(64, 16, 64), max_iter=40, early_stopping=True, random_state=seed).fit(clip(Xn[sub]), clip(Xn[sub]))
    timing["AE"] = time.time() - a
    aev = ((ae.predict(clip(Xv)) - clip(Xv)) ** 2).mean(1); aet = ((ae.predict(clip(Xt)) - clip(Xt)) ** 2).mean(1)
    for name, (v, t) in {"IF": (av, at), "AE": (aev, aet)}.items():
        thr = thr_for_far(v[yv == 0], 0.01)
        R["baseline"][name + "@1%"] = summarize(yt, t > thr, t, extra)
        R["baseline"][name + "@1%"]["val"] = metrics(yv, v > thr, v)
    # hybrid RF OR IF (IF at 1% validation FAR), as in the earlier version
    thr = thr_for_far(av[yv == 0], 0.01)
    R["baseline"]["RF+IF hybrid"] = summarize(yt, (st["RF"] > 0.5) | (at > thr), None, extra)
    R["timing_s"] = timing

    # ---------------- false-alarm control ----------------
    orders = {"shuffled": rng.permutation(len(yt))}
    if ds == "cic":
        orders = {"temporal": np.arange(len(yt))}
    else:
        orders["prevalence_drift"] = drift_order(yt, rng)
    FC = {}
    for det in ["RF", "XGB"]:
        s_v, s_t = sv[det], st[det]
        prior = float(yf.mean())
        q, pi_em = em_prior_adjust(s_t, prior)
        for oname, o in orders.items():
            s, a_, yy = s_t[o], at[o], yt[o]; ex = {k: v[o] for k, v in extra.items()}
            half = np.arange(len(yy)) >= len(yy) // 2
            for alpha in ALPHAS:
                key = f"{det}|{oname}|{alpha}"; res = {}
                ts = thr_for_far(s_v[yv == 0], alpha)
                res["default"] = summarize(yy, s > 0.5, None, ex)
                res["static"] = summarize(yy, s > ts, None, ex); res["static"]["t"] = ts
                res["static_2ndhalf"] = summarize(yy[half], (s > ts)[half])
                qe = q[o]
                res["em_prior"] = summarize(yy, qe > 0.5, None, ex); res["em_prior"]["pi_hat"] = pi_em
                Ft = exceed_curve(s[yy == 0]); i = np.where((Ft <= alpha) & (GRID < 1))[0]; to = float(GRID[i[0]]) if len(i) else float(GRID[GRID < 1][-1])
                res["oracle"] = summarize(yy, s > to, None, ex); res["oracle"]["t"] = to
                for b in BUDGETS:
                    for variant, kw in [("afac", {}), ("afac_nonovelty", dict(novelty=False)),
                                        ("uniform_audit", dict(novelty=False, stratified=False))]:
                        if variant != "afac" and b != 0.01: continue
                        A = AFAC(alpha, budget=b, **kw).fit(s_v, av, yv)
                        al, mask, log = A.run(s, a_, yy, np.random.default_rng(1000 + seed))
                        r = summarize(yy[mask], al[mask], None, {k: v[mask] for k, v in ex.items()})
                        m2 = mask & half
                        r["2ndhalf"] = metrics(yy[m2], al[m2])
                        r["labels_used"] = int((~mask).sum()); r["label_share"] = float((~mask).mean())
                        r["novel_windows"] = int(sum(l["novel"] for l in log)); r["windows"] = len(log)
                        r["t_median"] = float(np.median([l["t"] for l in log]))
                        # oracle on the same evaluation subset for reference
                        res[f"{variant}@{b}"] = r
                        if variant == "afac" and b == 0.01:
                            res["afac_trace"] = [dict(start=l["start"], t=l["t"], novel=l["novel"]) for l in log]
                            # per-window realised FAR / recall for plotting
                            W = A.window; tr = []
                            for st0 in range(0, len(yy), W):
                                sl = slice(st0, st0 + W); mm = mask[sl]; yw = yy[sl][mm]; aw = al[sl][mm]
                                tr.append(dict(start=st0, attack_share=float(yy[sl].mean()),
                                               far=float(100 * aw[yw == 0].mean()) if (yw == 0).any() else None,
                                               rec=float(100 * aw[yw == 1].mean()) if (yw == 1).any() else None,
                                               far_static=float(100 * (s[sl][yy[sl] == 0] > ts).mean()) if (yy[sl] == 0).any() else None))
                            res["afac_windows"] = tr
                FC[key] = res
    R["far_control"] = FC
    R["elapsed_s"] = time.time() - t0
    with open(os.path.join(OUT, f"main_{ds}_seed{seed}.json"), "w") as f:
        json.dump(R, f, default=lambda x: float(x) if isinstance(x, (np.floating, np.integer)) else str(x))
    print(ds, seed, "done in", round(time.time() - t0), "s", flush=True)


if __name__ == "__main__":
    ds = sys.argv[1]
    for s in sys.argv[2:]:
        run(ds, int(s))
