"""Sensitivity of AFAC-v2 to its only new setting, the share of the FAR budget given to the anomaly branch
(0.25, 0.5, 0.75), on the development streams (RF, 1% budget, 10 seeds). Same models/streams/audits as exp_main.
Usage: python exp_sens.py {nsl|unsw|cic} SEED [...] -> results/sens_<ds>_seed<k>.json"""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, load_cic, metrics, group_split
from afac import AFAC
from exp_main import stratified_subsample, drift_order, OUT

SHARES = [0.25, 0.5, 0.75]


def run(ds, D, seed):
    rng = np.random.default_rng(seed)
    X, y, fam = D.X_tr, D.y_tr, D.fam_tr
    if ds == "cic":
        sub = stratified_subsample(fam, 300000, rng); X, y = X[sub], y[sub]
    i_fit, i_val = group_split(X, y, 0.2, seed)
    Xf, yf, Xv, yv = X[i_fit], y[i_fit], X[i_val], y[i_val]
    rf = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=2).fit(Xf, yf)
    sv, st = rf.predict_proba(Xv)[:, 1], rf.predict_proba(D.X_te)[:, 1]
    Xn = Xf[yf == 0]
    iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(Xn)
    av, at = -iso.score_samples(Xv), -iso.score_samples(D.X_te)
    rng.choice(len(Xn), min(len(Xn), 60000), replace=False)      # same RNG consumption as exp_main
    o = rng.permutation(len(D.y_te)) if ds != "cic" else np.arange(len(D.y_te))
    s, a_, yy = st[o], at[o], D.y_te[o]; un = D.unseen_te[o]
    R = {}
    for alpha in [0.01, 0.05]:
        for sh in SHARES:
            A = AFAC(alpha, budget=0.01, anom_recal=True, anom_share=sh).fit(sv, av, yv)
            al, mask, log = A.run(s, a_, yy, np.random.default_rng(1000 + seed))
            r = metrics(yy[mask], al[mask])
            if un.any(): r["rec_unseen"] = float(100 * al[mask & un].mean())
            r["novel_windows"] = int(sum(l["novel"] for l in log)); R[f"{alpha}|{sh}"] = r
    json.dump(R, open(os.path.join(OUT, f"sens_{ds}_seed{seed}.json"), "w"))


if __name__ == "__main__":
    ds = sys.argv[1]; D = {"nsl": load_nsl, "unsw": load_unsw, "cic": load_cic}[ds]()
    for s in map(int, sys.argv[2:]):
        t = time.time(); run(ds, D, s); print(ds, s, round(time.time() - t), "s", flush=True)
