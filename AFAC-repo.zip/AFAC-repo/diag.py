"""Diagnostics cited in Section 3/5: duplicates, sources of false alarms, marginal shift, prevalence-estimate
sensitivity of label-free FAR estimation. Seed 0 throughout. -> results/diag.json"""
import os, sys, json
import numpy as np, pandas as pd
from sklearn.ensemble import RandomForestClassifier, IsolationForest, HistGradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.metrics import roc_auc_score
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, load_cic, group_split, DATA
from afac import exceed_curve, thr_for_far, GRID

out = {}
for L in [load_nsl, load_unsw, load_cic]:
    D = L(); name = D.name; o = out[name] = {}
    Xtr, ytr = D.X_tr, D.y_tr
    if name == "CIC-IDS2017":
        rng = np.random.default_rng(0); idx = rng.choice(len(ytr), 300000, replace=False); Xtr, ytr = Xtr[idx], ytr[idx]
    h = pd.util.hash_pandas_object(pd.DataFrame(Xtr), index=False).to_numpy()
    o["train_unique_share"] = float(len(np.unique(h)) / len(h))
    # random (non-group) split: share of validation records that are exact copies of fitting records
    i_fit, i_val = train_test_split(np.arange(len(ytr)), test_size=0.2, stratify=ytr, random_state=0)
    dup = np.isin(h[i_val], h[i_fit])
    o["random_split_val_dup_share"] = float(dup.mean())
    o["random_split_val_dup_share_attacks"] = float(dup[ytr[i_val] == 1].mean())
    o["random_split_val_dup_share_normals"] = float(dup[ytr[i_val] == 0].mean())
    # effect of duplicates on the validation attack profile at high thresholds (RF, seed 0)
    g_fit, g_val = group_split(Xtr, ytr, 0.2, 0)
    for tag, (f_, v_) in {"random": (i_fit, i_val), "group": (g_fit, g_val)}.items():
        rf = RandomForestClassifier(100, random_state=0, n_jobs=2).fit(Xtr[f_], ytr[f_])
        sv = rf.predict_proba(Xtr[v_])[:, 1]; st = rf.predict_proba(D.X_te)[:, 1]; yv = ytr[v_]
        o[f"{tag}_val_acc"] = float(100 * ((sv > 0.5) == yv).mean())
        o[f"{tag}_val_far"] = float(100 * (sv[yv == 0] > 0.5).mean())
        o[f"{tag}_recall_at_0.99_val"] = float(100 * (sv[yv == 1] > 0.99).mean())
        o[f"{tag}_recall_at_0.99_test"] = float(100 * (st[D.y_te == 1] > 0.99).mean())
        if tag == "group":
            iso = IsolationForest(n_estimators=200, random_state=0, n_jobs=2).fit(Xtr[f_][ytr[f_] == 0])
            av, at = -iso.score_samples(Xtr[v_]), -iso.score_samples(D.X_te)
            for q in [0.01, 0.05, 0.10]:
                tau = thr_for_far(av[yv == 0], q)
                o[f"IF_far_val_{q}"] = float(100 * (av[yv == 0] > tau).mean())
                o[f"IF_far_test_{q}"] = float(100 * (at[D.y_te == 0] > tau).mean())
            # sensitivity of label-free FAR estimation to the attack-prevalence estimate (target 1%)
            R = exceed_curve(sv[yv == 1]); A = exceed_curve(st); pi_true = float(D.y_te.mean())
            sens = {}
            for dpi in [-0.10, -0.05, 0.0, 0.05, 0.10]:
                pi = pi_true + dpi; F = (A - pi * R) / (1 - pi)
                ok = np.where((F <= 0.01) & (GRID < 1))[0]; t = float(GRID[ok[0]]) if len(ok) else 1.0
                sens[f"{dpi:+.2f}"] = dict(t=t, far=float(100 * (st[D.y_te == 0] > t).mean()), rec=float(100 * (st[D.y_te == 1] > t).mean()),
                                         min_F_est=float(100 * F.min()))
            o["labelfree_sensitivity"] = sens; o["pi_true"] = pi_true
            fa = (D.y_te == 0) & (st > 0.5); o["false_alarms_default"] = int(fa.sum())
            if name == "UNSW-NB15":
                d = os.path.join(DATA, "ML-Projects", "UNSW-Network_Packet_Classification")
                te = pd.read_csv(os.path.join(d, "UNSW_NB15_testing-set.csv"), encoding="utf-8-sig")
                tr = pd.read_csv(os.path.join(d, "UNSW_NB15_training-set.csv"), encoding="utf-8-sig")
                o["fa_sttl254_share"] = float((te.sttl[fa] == 254).mean())
                o["sttl254_share_normals_train"] = float((tr.sttl[tr.label == 0] == 254).mean())
                o["sttl254_share_normals_test"] = float((te.sttl[te.label == 0] == 254).mean())
                o["sttl254_share_attacks_train"] = float((tr.sttl[tr.label == 1] == 254).mean())
                o["fa_service_dash_share"] = float((te.service[fa] == "-").mean())
    # marginal (unlabelled) shift: domain classifier train-vs-test
    rng = np.random.default_rng(0); n = min(len(ytr), len(D.y_te), 60000)
    a = rng.choice(len(ytr), n, replace=False); b = rng.choice(len(D.y_te), n, replace=False)
    X = np.vstack([Xtr[a], D.X_te[b]]); d = np.r_[np.zeros(n), np.ones(n)]
    p = cross_val_predict(HistGradientBoostingClassifier(max_iter=200, random_state=0), X, d, cv=3, method="predict_proba")[:, 1]
    o["domain_auc"] = float(roc_auc_score(d, p))
    print(name, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in o.items() if not isinstance(v, dict)}, flush=True)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "results", "diag.json"), "w"), indent=1)
