# Frozen protocol: independent validation of AFAC-v2 on five unseen CIC-IDS2017 days

Written and hashed **before** any of the five test files below was loaded by any model or inspected for labels.
The SHA-256 hashes of this file and of all code used are recorded in `protocol_freeze.json` together with a UTC
timestamp. No code, setting or threshold is changed after the freeze; any deviation must be reported as such.

## Data
- Training: Monday + Wednesday (identical to the main CIC-IDS2017 experiment; same duplicate removal, same
  family-stratified 300,000-row sample per seed, same duplicate-aware 80/20 split, same preprocessing).
- Test streams (each evaluated separately, in original file order = time order):
  1. Tuesday (FTP-Patator, SSH-Patator)
  2. Thursday morning (Web attacks)
  3. Thursday afternoon (Infiltration; very few attacks, so recall is reported but not interpreted)
  4. Friday morning (Bot)
  5. Friday afternoon PortScan
  None of these attack types occurs in the training days. None of these files was used during the development of
  AFAC or AFAC-v2.

## Methods (all settings exactly as in the paper; no tuning)
- Detectors: Random Forest (primary) and XGBoost (secondary), Isolation Forest for the anomaly branch.
- Threshold methods: default 0.5, static validation calibration, uniform audit, AFAC without novelty trigger,
  AFAC (pre-specified), **AFAC-v2 (primary method under test)**, oracle threshold (reference only).
- Targets α = 1% and 5%; audit budget 1%; window 2,000; K = 25; stratified share 0.8; trigger gap 0.10, z < −2.33;
  anomaly share of the FAR budget 0.5.
- Seeds 0–9.

## Primary endpoint and pre-stated success criteria (Random Forest)
- E1: |realised FAR − target| of AFAC-v2 versus static calibration; paired two-sided Wilcoxon over ten seeds,
  Holm correction over the 10 tests (5 days × 2 targets).
  **Criterion S1:** AFAC-v2 is significantly closer to the target (Holm p < 0.05) in at least 8 of 10 tests.
- E2: mean realised FAR of AFAC-v2 at most target + 1 percentage point (≤ 2% for α = 1%, ≤ 6% for α = 5%).
  **Criterion S2:** met in at least 8 of 10 day × target combinations.
- E3 (descriptive): recall of AFAC-v2 minus recall of the oracle threshold.
- Secondary: the same for XGBoost; AFAC-v2 versus AFAC (pre-specified) and versus uniform audit.

All results, whether or not the criteria are met, are reported in the paper.
