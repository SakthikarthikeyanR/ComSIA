import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({"font.family":"serif","font.serif":["DejaVu Serif"],"mathtext.fontset":"dejavuserif"})
fig,ax=plt.subplots(figsize=(11,5.2)); ax.set_xlim(0,110); ax.set_ylim(0,52); ax.axis("off")
FS=7.6
def box(x,y,w,h,text,fc="#ffffff",ec="#333333",fs=FS):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.25,rounding_size=1.0",fc=fc,ec=ec,lw=1.0))
    ax.text(x+w/2,y+h/2,text,ha="center",va="center",fontsize=fs,linespacing=1.35)
def arr(x1,y1,x2,y2,ls="-",c="#333333",rad=0.0):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=9,lw=0.9,color=c,linestyle=ls,connectionstyle=f"arc3,rad={rad}"))
def panel(x,y,w,h,title):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.3,rounding_size=1.5",fc="#f6f6f6",ec="#a0a0a0",lw=0.8))
    ax.text(x+1.2,y+h-1.6,title,ha="left",va="center",fontsize=8,style="italic")
panel(0.5,28,109,23,"Offline: training file only")
box(2,34,18,10,"Labelled training\nrecords")
box(26,34,22,10,"Duplicate-aware 80/20\ngroup split\n(identical vectors kept\non the same side)")
box(54,34,24,10,"Fit on 80%:\nsupervised detector RF / XGBoost\nanomaly detector IF\n(normal records only)")
box(84,30.5,24,16,"Validation profile (20%)\n\nstatic threshold $t_0(\\alpha)$\nattack profile $R(t)$\nIF thresholds $\\tau_{10\\%}$, $\\tau_{\\alpha/2}$",fc="#eef3fb",ec="#4472c4")
arr(20,39,26,39); arr(48,39,54,39); arr(78,39,84,39)
panel(0.5,0.5,109,25.5,"Online: traffic processed in windows of 2,000 records (no unaudited label is used)")
box(2,11,14,8,"Traffic window $w_k$\n(flow records)")
box(20,11,17,8,"Scores\n$s(x)$ supervised\n$a(x)$ anomaly")
box(41,10,22,10,"Alert rule\n$s(x) > t_k$\n[ OR $a(x) > \\tau_{\\alpha/2}$\nin novel-attack mode ]",fc="#fff4e5",ec="#ed7d31")
box(67,11,15,8,"Alerts to the\nanalyst queue")
box(86,10,22,10,"Stratified audit, budget $b$\n80%: suspicious records\n20%: remaining records\nHorvitz–Thompson weights",fc="#eef7ee",ec="#3a923a")
box(41,1.8,67,6,"Recalibration from audited records of the last $K$=25 windows:  $t_{k+1}=\\min\\{t:\\ \\widehat{\\mathrm{FAR}}(t)\\leq\\alpha\\}$\nnovel-attack test: audited attacks detected at $t=0.5$ vs. $R(0.5)$ (one-sided z-test, gap $\\geq$ 0.10)",fc="#eef7ee",ec="#3a923a",fs=7.3)
box(2,1.8,35,6,"Start (no audited normals yet): $t_1=t_0(\\alpha)$,\nanomaly branch off",fs=7.3)
arr(16,15,20,15); arr(37,15,41,15); arr(63,15,67,15); arr(82,15,86,15); arr(97,10,97,7.8)
arr(55,7.8,52,10,ls="--",c="#3a923a"); ax.annotate("",xy=(56,20),xytext=(90,30.5),arrowprops=dict(arrowstyle="-|>",lw=0.9,color="#4472c4",linestyle="--",connectionstyle="arc3,rad=0.15",mutation_scale=9)); arr(37,4.8,41,4.8,ls="--")
fig.savefig("figs/fig1_architecture.png",dpi=220,bbox_inches="tight"); print("ok")
