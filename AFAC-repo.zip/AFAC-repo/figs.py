"""Figures 2-5 from results/*.json (Figure 1 is fig_arch.py)."""
import json, os, glob
import numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "serif", "font.serif": ["DejaVu Serif"], "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.alpha": 0.25, "mathtext.fontset": "dejavuserif"})
R = "results"; F = "figs"
S = json.load(open(f"{R}/summary.json"))
C = {"default": "#7f7f7f", "static": "#c0504d", "em_prior": "#9467bd", "uniform_audit@0.01": "#8c564b",
     "afac_nonovelty@0.01": "#2ca02c", "afac@0.01": "#ed7d31", "afac_v2@0.01": "#4472c4", "oracle": "#000000"}
LAB = {"default": "Default (0.5)", "static": "Static calibration", "em_prior": "EM prior adjustment",
       "uniform_audit@0.01": "Uniform audit (1%)", "afac_nonovelty@0.01": "AFAC, no novelty trigger",
       "afac@0.01": "AFAC (pre-specified)", "afac_v2@0.01": "AFAC-v2", "oracle": "Oracle threshold"}
MK = {"default": "o", "static": "s", "em_prior": "v", "uniform_audit@0.01": "D", "afac_nonovelty@0.01": "^",
      "afac@0.01": "P", "afac_v2@0.01": "*", "oracle": "X"}

# ---- Figure 2: realised FAR vs recall per dataset (RF), target 1% and 5%
fig, axes = plt.subplots(2, 3, figsize=(10.5, 6.0))
for j, (ds, order) in enumerate([("NSL-KDD", "shuffled"), ("UNSW-NB15", "shuffled"), ("CIC-IDS2017", "temporal")]):
    for i, alpha in enumerate([0.01, 0.05]):
        ax = axes[i, j]; fc = S[ds]["far_control"][f"RF|{order}|{alpha}"]
        for m in C:
            if m not in fc: continue
            f, r = fc[m]["far"], fc[m]["rec"]
            ax.errorbar(f["mean"], r["mean"], xerr=f["ci"], yerr=r["ci"], fmt=MK[m], color=C[m], ms=7 if m != "afac_v2@0.01" else 10,
                        capsize=2, lw=0.8, label=LAB[m] if (i == 0 and j == 0) else None)
        ax.axvline(100 * alpha, color="k", ls=":", lw=0.9)
        ax.set_xscale("symlog", linthresh=1); ax.set_xlim(-0.05, 40)
        ax.set_xticks([0, 1, 2, 5, 10, 20]); ax.set_xticklabels(["0", "1", "2", "5", "10", "20"])
        ax.set_title(f"{ds}, target FAR {int(alpha*100)}%", fontsize=9)
        if i == 1: ax.set_xlabel("Realised false alarm rate (%)")
        if j == 0: ax.set_ylabel("Recall (%)")
fig.legend(loc="lower center", ncol=4, fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.02))
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(f"{F}/fig2_far_recall.png", dpi=220); plt.close(fig)

# ---- Figure 3: per-window trace on the CIC-IDS2017 temporal stream (RF, alpha 1%, seed 0)
main = json.load(open(f"{R}/main_cic_seed0.json"))["far_control"]["RF|temporal|0.01"]
v2f = f"{R}/v2_cic_seed0.json"
v2 = json.load(open(v2f))["RF|temporal|0.01"]["v2_windows"] if os.path.exists(v2f) else None
W = main["afac_windows"]; x = np.array([w["start"] for w in W]) / 1000
fig, ax = plt.subplots(2, 1, figsize=(9, 5.0), sharex=True, gridspec_kw={"height_ratios": [1, 2]})
ax[0].fill_between(x, [100 * w["attack_share"] for w in W], step="post", color="#d9d9d9")
ax[0].set_ylabel("Attack share (%)"); ax[0].set_ylim(0, 100)
nan = lambda v: np.nan if v is None else v
ax[1].step(x, [nan(w["far_static"]) for w in W], where="post", color=C["static"], label="Static calibration")
ax[1].step(x, [nan(w["far"]) for w in W], where="post", color=C["afac@0.01"], label="AFAC (pre-specified)")
if v2: ax[1].step(x, [nan(w["far"]) for w in v2], where="post", color=C["afac_v2@0.01"], label="AFAC-v2", lw=1.6)
ax[1].axhline(1, color="k", ls=":", lw=0.9, label="Target 1%")
ax[1].set_yscale("symlog", linthresh=1); ax[1].set_ylim(0, 100); ax[1].set_yticks([0, 1, 10, 100]); ax[1].set_yticklabels(["0", "1", "10", "100"])
ax[1].set_ylabel("False alarm rate in window (%)")
ax[1].set_xlabel("Position in the Friday-afternoon stream (thousands of flows, time order)")
ax[1].legend(fontsize=8, ncol=2, frameon=False)
fig.tight_layout(); fig.savefig(f"{F}/fig3_cic_trace.png", dpi=220); plt.close(fig)

# ---- Figure 4: held-out family recall (leave-one-family-out), NSL-KDD, target 5%
L = S["robust_lofo"]["NSL-KDD"]; fams = [f for f in L if f != "n_seeds"]
meths = [("RF", "RF (0.5)", "#7f7f7f"), ("RF+IF", "RF + IF hybrid", "#9467bd"), ("AFAC-nonovelty@5%", "AFAC, no trigger", "#2ca02c"),
         ("AFAC@5%", "AFAC", "#ed7d31"), ("AFAC-v2@5%", "AFAC-v2", "#4472c4")]
fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.4))
w = 0.16; xx = np.arange(len(fams))
for k, (m, lab, col) in enumerate(meths):
    ax[0].bar(xx + (k - 2) * w, [L[f][m]["rec_heldout"]["mean"] for f in fams], w, yerr=[L[f][m]["rec_heldout"]["ci"] for f in fams],
              color=col, label=lab, capsize=2, error_kw=dict(lw=0.7))
    ax[1].bar(xx + (k - 2) * w, [L[f][m]["far"]["mean"] for f in fams], w, yerr=[L[f][m]["far"]["ci"] for f in fams],
              color=col, capsize=2, error_kw=dict(lw=0.7))
for a, yl in zip(ax, ["Recall on held-out family (%)", "False alarm rate (%)"]):
    a.set_xticks(xx); a.set_xticklabels(fams); a.set_ylabel(yl)
ax[1].axhline(5, color="k", ls=":", lw=0.9)
ax[0].set_ylim(0, 125); ax[0].legend(fontsize=7, frameon=False, ncol=3, loc="upper left")
fig.tight_layout(); fig.savefig(f"{F}/fig4_lofo_nsl.png", dpi=220); plt.close(fig)

# ---- Figure 5: label budget sensitivity (RF, target 5%), FAR and recall
fig, ax = plt.subplots(1, 2, figsize=(9.5, 3.2))
for ds, order, col in [("NSL-KDD", "shuffled", "#c0504d"), ("UNSW-NB15", "shuffled", "#4472c4"), ("CIC-IDS2017", "temporal", "#2ca02c")]:
    fc = S[ds]["far_control"][f"RF|{order}|0.05"]; bs = [0.005, 0.01, 0.02]
    key = "afac_v2@" if "afac_v2@0.01" in fc else "afac@"
    for a, met in zip(ax, ["far", "rec"]):
        a.errorbar([100 * b for b in bs], [fc[f"{key}{b}"][met]["mean"] for b in bs], yerr=[fc[f"{key}{b}"][met]["ci"] for b in bs],
                   marker="o", color=col, capsize=2, label=ds)
ax[0].axhline(5, color="k", ls=":", lw=0.9); ax[0].set_ylabel("Realised false alarm rate (%)"); ax[1].set_ylabel("Recall (%)")
for a in ax: a.set_xlabel("Audit budget (% of traffic labelled)"); a.set_xticks([0.5, 1, 2])
ax[0].legend(fontsize=8, frameon=False)
fig.tight_layout(); fig.savefig(f"{F}/fig5_budget.png", dpi=220); plt.close(fig)
print("figures written")
