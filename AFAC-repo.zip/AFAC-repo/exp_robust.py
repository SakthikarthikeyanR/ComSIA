"""Robustness experiments: (a) class imbalance, (b) unseen attack families (leave-one-family-out).
Usage: python exp_robust.py {nsl|unsw} {imbalance|lofo} SEED [SEED ...]
"""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, metrics, group_split
from afac import AFAC, thr_for_far

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


def fit_scores(Xf, yf, Xv, Xt, seed, balanced=False):
    rf = RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=2,
                                class_weight="balanced" if balanced else None).fit(Xf, yf)
    return rf.predict_proba(Xv)[:, 1], rf.predict_proba(Xt)[:, 1]


def imbalance(D, seed):
    rng = np.random.default_rng(seed)
    i_fit, i_val = group_split(D.X_tr, D.y_tr, 0.2, seed)
    iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(D.X_tr[i_fit][D.y_tr[i_fit] == 0])
    av, at = -iso.score_samples(D.X_tr[i_val]), -iso.score_samples(D.X_te)
    yv, yt = D.y_tr[i_val], D.y_te
    order = rng.permutation(len(yt))
    out = {}
    for share in ["orig", 0.10, 0.01]:
        f = i_fit
        if share != "orig":
            nor = f[D.y_tr[f] == 0]; att = f[D.y_tr[f] == 1]
            k = int(round(share / (1 - share) * len(nor)))
            f = np.sort(np.r_[nor, rng.choice(att, min(k, len(att)), replace=False)])
        for bal in [False, True]:
            sv, st = fit_scores(D.X_tr[f], D.y_tr[f], D.X_tr[i_val], D.X_te, seed, bal)
            r = dict(attack_share_fit=float(D.y_tr[f].mean()), n_fit=int(len(f)))
            r["default"] = metrics(yt, st > 0.5, st)
            ts = thr_for_far(sv[yv == 0], 0.05); r["static@5%"] = metrics(yt, st > ts)
            A = AFAC(0.05, budget=0.01).fit(sv, av, yv)
            al, mask, log = A.run(st[order], at[order], yt[order], np.random.default_rng(1000 + seed))
            r["afac@5%"] = metrics(yt[order][mask], al[mask])
            out[f"{share}|{'balanced' if bal else 'plain'}"] = r
    return out


def lofo(D, seed):
    fams = [f for f in np.unique(D.fam_tr) if f not in ("normal", "Normal", "U2R")]
    out = {}
    rng = np.random.default_rng(seed)
    i_fit0, i_val0 = group_split(D.X_tr, D.y_tr, 0.2, seed)
    yt = D.y_te; order = rng.permutation(len(yt))
    for fam in fams:
        keep = D.fam_tr != fam
        i_fit, i_val = i_fit0[keep[i_fit0]], i_val0[keep[i_val0]]
        yv = D.y_tr[i_val]
        sv, st = fit_scores(D.X_tr[i_fit], D.y_tr[i_fit], D.X_tr[i_val], D.X_te, seed)
        iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(D.X_tr[i_fit][D.y_tr[i_fit] == 0])
        av, at = -iso.score_samples(D.X_tr[i_val]), -iso.score_samples(D.X_te)
        held = D.fam_te == fam
        def rep(pred, mask=None):
            m = np.ones(len(yt), bool) if mask is None else mask
            r = metrics(yt[m], pred[m]); r["rec_heldout"] = float(100 * pred[m & held].mean()) if (m & held).any() else None
            r["rec_other"] = float(100 * pred[m & (yt == 1) & ~held].mean())
            return r
        r = dict(n_test_heldout=int(held.sum()))
        r["RF"] = rep(st > 0.5)
        tau = thr_for_far(av[yv == 0], 0.01)
        r["RF+IF"] = rep((st > 0.5) | (at > tau))
        for alpha in [0.01, 0.05]:
            for nov, tag, kw in [(True, "", {}), (False, "-nonovelty", {}), (True, "-v2", dict(anom_recal=True))]:
                A = AFAC(alpha, budget=0.01, novelty=nov, **kw).fit(sv, av, yv)
                al, mask, log = A.run(st[order], at[order], yt[order], np.random.default_rng(1000 + seed))
                pred = np.zeros(len(yt), bool); pred[order] = al; m = np.zeros(len(yt), bool); m[order] = mask
                rr = rep(pred, m); rr["novel_windows"] = int(sum(l["novel"] for l in log)); rr["windows"] = len(log)
                r[f"AFAC{tag}@{int(alpha*100)}%"] = rr
        out[fam] = r
    return out


if __name__ == "__main__":
    ds, exp = sys.argv[1], sys.argv[2]
    D = {"nsl": load_nsl, "unsw": load_unsw}[ds]()
    for s in map(int, sys.argv[3:]):
        t = time.time()
        res = {"imbalance": imbalance, "lofo": lofo}[exp](D, s)
        json.dump(res, open(os.path.join(OUT, f"robust_{exp}_{ds}_seed{s}.json"), "w"))
        print(ds, exp, s, round(time.time() - t), "s", flush=True)
