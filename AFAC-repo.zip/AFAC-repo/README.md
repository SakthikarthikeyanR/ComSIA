# AFAC: Adaptive False-Alarm Control for ML-based NIDS — reproducibility bundle

Code, configuration, frozen validation protocol and all result files behind the manuscript *Adaptive False-Alarm Control for Machine-Learning Network Intrusion Detection under Changing Traffic*.

## Quick start
```
pip install -r requirements.txt
IDS_DATA=./data ./download_data.sh          # downloads public mirrors and verifies SHA-256 (checksums.sha256)
```

## Data (not included; public mirrors)
Place under the folder given by the environment variable `IDS_DATA` (set it explicitly; `download_data.sh` uses `./data`):
- `NSL_KDD/` — https://github.com/defcom17/NSL_KDD (KDDTrain+.txt, KDDTest+.txt, KDDTest-21.txt)
- `ML-Projects/UNSW-Network_Packet_Classification/` — https://github.com/Nir-J/ML-Projects (UNSW_NB15_training-set.csv, UNSW_NB15_testing-set.csv)
- `cic2017/` — the eight CIC-IDS2017 MachineLearningCVE files (Git LFS objects of github.com/bibhash074/Machine-Learning;
  Monday/Wednesday also from github.com/antiantimailed-dotcom/CSCI6330-Detector-Project; Friday DDoS from
  github.com/SHUBHAMRAWAT-25/DDOS-attack-detection-using-random-forest-algorithm). The SHA-256 checksums equal the Git LFS
  object IDs listed independently by github.com/roshanyadav7/Machine-Learning-CVE.
SHA-256 checksums of every input file are stored in `results/main_*_seed*.json` (`files`).

## Environment
Python 3.13, scikit-learn 1.9.1, XGBoost 3.4.1, NumPy 2.5.3, pandas 3.0.5, SciPy 1.18.1, matplotlib; Node.js with `docx` for the manuscript.

## Run order
```
python exp_main.py nsl 0 1 2 3 4 5 6 7 8 9      # baselines + threshold control (also unsw, cic)
python exp_v2.py   nsl 0 1 2 3 4 5 6 7 8 9      # post-hoc AFAC-v2; checks reproduction of exp_main
python exp_robust.py nsl imbalance 0 ... 9      # imbalance (unsw: seeds 0-4)
python exp_robust.py nsl lofo 0 1 2 3 4         # leave-one-family-out (also unsw)
python exp_fs.py nsl ; python exp_fs.py unsw    # feature selection
python diag.py                                  # diagnostics (duplicates, sttl, IF transfer, label-free sensitivity)
python exp_sens.py nsl 0 ... 9                  # AFAC-v2 sensitivity to the anomaly share (also unsw, cic)
python exp_independent.py 0 1 2 3 4 5 6 7 8 9   # FROZEN independent validation on five unseen CIC-IDS2017 days
python summarize_indep.py                       # pre-specified endpoints S1/S2 -> results/indep_summary.json
python summarize.py                             # -> results/summary.json (means, 95% CIs, Wilcoxon, Holm families)
python fig_arch.py ; python figs.py             # figures
python build_final.py && node render.js paper_spec_final.json IDS_Paper_Final.docx   # author/repo in paper_config.json
python verify_paper.py IDS_Paper_Final.docx    # every decimal number in the paper traced to results
python check_paper.py IDS_Paper_Final.docx     # citations, table/figure order, abbreviations, placeholders
```

## Files
- `common.py` data loading, preprocessing, metrics, duplicate-aware group split
- `afac.py` AFAC method (stratified audit, Horvitz–Thompson FAR estimate, threshold update, novelty trigger; `anom_recal=True` = AFAC-v2) and EM prior adjustment
- `exp_*.py`, `diag.py` experiments; `summarize.py` aggregation and statistics
- `paper_tables.py`, `build_final.py`, `build_paper_refs.py`, `render.js` manuscript generation; `verify_paper.py` number check; `check_paper.py` formatting check
- `results/` per-seed JSON outputs and `summary.json`; `figs/` figures

## Protocol notes
- AFAC was developed on NSL-KDD and UNSW-NB15. The CIC-IDS2017 (Friday DDoS) run of `exp_main.py` was executed once with fixed settings.
- AFAC-v2 (`exp_v2.py`, `anom_recal=True` in `afac.py`) was written after that run and is post hoc.
- AFAC-v2 was then frozen: `PROTOCOL_independent_validation.md` (endpoints, success criteria) and the SHA-256 of all code were recorded in
  `protocol_freeze.json` before `exp_independent.py` touched the five remaining days. One deviation (memory-safe loading, output verified
  byte-identical on a previously used file) is logged there with the new hashes. Results are reported whether or not the criteria were met
  (S1 not met, S2 met).
