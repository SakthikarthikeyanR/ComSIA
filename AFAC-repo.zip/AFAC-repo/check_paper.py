"""Formatting/consistency checks on the built manuscript (.docx):
citations (all cited, none dangling, numbered by first appearance), table/figure references (each cited, in order),
abbreviations defined before use, placeholders, doubled words, double spaces, empty brackets."""
import re, sys, zipfile, html
doc = sys.argv[1]
xml = zipfile.ZipFile(doc).read("word/document.xml").decode("utf8")
paras = [html.unescape(re.sub(r"<[^>]+>", "", p)) for p in re.findall(r"<w:p[ >].*?</w:p>", xml, flags=re.S)]
text = "\n".join(paras)
i_ref = max(i for i, p in enumerate(paras) if p.strip() == "References")
body, refs = "\n".join(paras[:i_ref]), [p for p in paras[i_ref + 1:] if re.match(r"\[\d+\]", p)]
problems = []

def expand(tok):
    out = []
    for part in re.findall(r"\[(\d+)\](?:\s*[–-]\s*\[(\d+)\])?", tok):
        a = int(part[0]); b = int(part[1]) if part[1] else a
        out += list(range(a, b + 1))
    return out

cites = []
for m in re.finditer(r"\[\d+\](?:\s*[–-]\s*\[\d+\])?(?:,\s*\[\d+\](?:\s*[–-]\s*\[\d+\])?)*", body):
    cites += expand(m.group(0))
nref = len(refs)
first = []
for c in cites:
    if c not in first: first.append(c)
if sorted(set(cites)) != list(range(1, nref + 1)):
    problems.append(f"cited set {sorted(set(cites))} != 1..{nref}")
if first != sorted(first):
    problems.append(f"references not in order of first citation: {first}")
for kind in ["Table", "Figure"]:
    caps = [int(x) for x in re.findall(rf"^{kind} (\d+)\.", body, flags=re.M)]
    if caps != list(range(1, len(caps) + 1)): problems.append(f"{kind} captions not sequential: {caps}")
    mentions = [int(x) for x in re.findall(rf"{kind}s? (\d+)(?!\.\s)", body)]
    for n in caps:
        if n not in mentions: problems.append(f"{kind} {n} never referenced in text")
    order = []
    for n in mentions:
        if n not in order: order.append(n)
    if order != sorted(order): problems.append(f"{kind} first mentions out of order: {order}")
for ab, full in [("FAR", "false alarm rate (FAR)"), ("RF", "Random Forest (RF)"), ("IF", "Isolation Forest (IF)"), ("PR-AUC", "PR-AUC"),
                 ("AFAC", "Adaptive False-Alarm Control (AFAC)"), ("NIDS", "(NIDS)")]:
    mdef = re.search(re.escape(full).replace(r"\)", r"[,)]"), body); pos_def = mdef.start() if mdef else -1; pos_use = re.search(rf"\b{re.escape(ab)}\b", body)
    if pos_def < 0: problems.append(f"abbreviation {ab} never defined as '{full}'")
    elif pos_use and pos_use.start() < pos_def - len(full) and ab not in full[:len(ab)]:
        problems.append(f"abbreviation {ab} used before definition")
for pat, what in [(r"\[[A-Z][^\]]*to be added[^\]]*\]", "placeholder"), (r"\[Author Name\]|\[Affiliation", "author placeholder"),
                  (r"\b(\w+) \1\b", "doubled word"), (r"  +", "double space"), (r"\(\s*\)", "empty brackets")]:
    for m in re.finditer(pat, body):
        if what == "doubled word" and m.group(1).isdigit(): continue
        problems.append(f"{what}: …{body[max(0, m.start() - 30):m.end() + 30]!r}")
print(f"paragraphs {len(paras)}, references {nref}, citations {len(cites)}")
print("\n".join(problems) if problems else "no problems found")
sys.exit(1 if problems else 0)
