"""Condensed manuscript (< 10 pages). All numbers come from results/*.json via helpers -> paper_spec_short.json"""
import json
from paper_tables import S, DG, NUMBERS, mci, m, bl, fc
import re
CFG = json.load(open("paper_config.json"))
IND = json.load(open("results/indep_summary.json"))

B = []
def H1(t): B.append(dict(type="h1", text=t))
def H2(t): B.append(dict(type="h2", text=t))
def P(t): B.append(dict(type="p", text=t))
def BUL(t): B.append(dict(type="bullet", text=t))
def NUM(t): B.append(dict(type="num", text=t, ref="steps"))
def EQ(t, label): B.append(dict(type="eq", text=t, label=label))
def CAP(t, keep=True): B.append(dict(type="caption", text=t, keepNext=keep))
def TAB(t, note=None):
    if note: t["note"] = note
    B.append(t)
def FIG(path, ratio, width, alt): B.append(dict(type="figure", path=path, ratio=ratio, width=width, alt=alt))
def g(x, d=2):
    s = f"{x:.{d}f}"; NUMBERS.append(s); return s
def pct(x, d=1): return g(100 * x, d)
def ic(stat):
    v = f"{int(round(stat['mean'])):,}"; NUMBERS.append(v); return v

N, U, C = "NSL-KDD", "UNSW-NB15", "CIC-IDS2017"
K = lambda ds, a, det="RF": f"{det}|{'temporal' if ds == C else 'shuffled'}|{a}"
KD = lambda ds, a, det="RF": f"{det}|prevalence_drift|{a}"
F = S["families"]; LO = S["robust_lofo"]; IM = S["robust_imbalance"]; FS = S["feature_selection"]
def lo(ds, f, meth, k="rec_heldout", d=1): return m(LO[ds][f][meth][k], d)
def im(ds, cond, meth, k, d=1): return m(IM[ds][cond][meth][k], d)
H = "̂"

# ------------------------------------------------------------------ front matter
B.append(dict(type="title", text="Adaptive False-Alarm Control for Machine-Learning Network Intrusion Detection under Changing Traffic"))
B.append(dict(type="center", text="**" + CFG["authors"] + "**"))
B.append(dict(type="center", text=CFG["affiliation"], size=18))
B.append(dict(type="center", text="Corresponding author: " + CFG["email"], size=18))
P("**Abstract**")
B.append(dict(type="abstract", text=(
    "Intrusion detectors are usually calibrated once, on data that resemble the training traffic, and then deployed on traffic that does not, so the false alarm rate (FAR) drifts away from the one the operator chose. "
    "This paper proposes Adaptive False-Alarm Control (AFAC), a model-agnostic layer that recalibrates a detector's alert threshold window by window from a 1% stratified audit sample, and switches on a normal-only "
    "anomaly branch when audited attacks show that a new attack type is being missed. AFAC is evaluated with ten seeds, 95% confidence intervals and Holm-corrected Wilcoxon tests on NSL-KDD, UNSW-NB15 and a cross-day "
    "split of CIC-IDS2017 whose test attack (DDoS) is absent from training. "
    f"On UNSW-NB15 the Random Forest flags {bl(U,'RF','far')}% of normal records at its default threshold and {fc(U,K(U,0.05),'static','far')}% when calibrated on validation data for a 5% target; AFAC reaches "
    f"{fc(U,K(U,0.05),'afac_v2@0.01','far')}% at {fc(U,K(U,0.05),'afac_v2@0.01','rec',1)}% recall, close to an oracle threshold ({fc(U,K(U,0.05),'oracle','far')}% at {fc(U,K(U,0.05),'oracle','rec',1)}%). "
    "AFAC is significantly closer to the target FAR than static calibration in 11 of 12 pre-stated comparisons, at the cost of the recall that static thresholds obtain by exceeding the target. "
    "The confirmatory CIC-IDS2017 run exposed a flaw: the anomaly branch, calibrated offline, raised false alarms on "
    f"{bl(C,'IF@1%','far',1)}% of Friday's benign traffic. A post-hoc revision (AFAC-v2) that measures this branch on audited traffic lowers the FAR for a 1% target from "
    f"{fc(C,K(C,0.01),'afac@0.01','far')}% to {fc(C,K(C,0.01),'afac_v2@0.01','far')}%. In a frozen validation on five further CIC-IDS2017 days never used in development, AFAC-v2 kept the FAR within one point "
    f"of the target in all 10 day–target combinations, where static calibration reached up to {m(IND['days']['Thursday-PM']['RF|0.05|static']['far'],1)}%, but it was significantly closer to the target than static calibration in only "
    f"{IND['endpoints']['RF']['S1_count']} of 10, below the pre-stated 8, because static thresholds were already adequate on three days. Stratified auditing was not better than uniform auditing.")))
P("**Keywords:** network intrusion detection, false alarm rate, threshold calibration, distribution shift, analyst feedback, NSL-KDD, UNSW-NB15, CIC-IDS2017")

# ------------------------------------------------------------------ 1 introduction
H1("1. Introduction")
P("Machine learning has become central to network intrusion detection systems (NIDS) because signature-based systems are blind to new attacks [1], [2]. The operational bottleneck, however, is not accuracy but false alarms: every alert "
  "is triaged by an analyst, and because normal traffic vastly outnumbers attacks, a FAR of a few per cent buries the true alerts [7]. Operators therefore set the alert threshold for a target FAR. In the earlier version "
  "of this study, a Random Forest flagged 27% of normal UNSW-NB15 records at its default threshold, and thresholds calibrated for 1% FAR on validation data produced roughly ten times that rate on the test split. "
  "Benchmark evaluations rarely report this, because the test set is treated as a single stationary batch [16], [26].")
P("The cause is a change in traffic between calibration and deployment, in attack prevalence, in the normal traffic and in the attacks themselves. Label-free prior correction [17] assumes the class-conditional "
  "distributions are unchanged, which fails here (Section 5.2). Labelling every record is impossible, but in a security operations centre a small number of records is labelled routinely. This paper asks how far a small, "
  "deliberately sampled audit can keep a deployed detector at its target FAR, and what that costs in detection. The contributions are:")
BUL("**AFAC**, a threshold-control layer for any scoring detector that estimates the FAR from a stratified audit with Horvitz–Thompson weights and enables a normal-only anomaly branch when audited attacks reveal a detection gap (Section 3).")
BUL("**A controlled evaluation** on three datasets, including a cross-day CIC-IDS2017 split with an unseen attack type, with ten seeds, 95% CIs, PR-AUC and Holm-corrected paired tests in pre-stated families (Sections 4–5).")
BUL("**Diagnostics and an honest account of failures**: duplicate leakage into validation splits, a shortcut feature behind most UNSW-NB15 false alarms, a pre-specified design that failed on CIC-IDS2017 and its post-hoc repair, and robustness to imbalance, prevalence drift and unseen attack families.")

# ------------------------------------------------------------------ 2 related work
H1("2. Related Work")
P("Tree ensembles are strong baselines on the public benchmarks: Türk reports 97.8% (NSL-KDD) and 98.6% (UNSW-NB15) two-class accuracy [4], Alzahrani and Alenazi 95.95% multi-class accuracy with five NSL-KDD features "
  "for an SDN controller [5], and Vibhute et al. validation accuracies up to 98.24% [6]. These studies evaluate a single operating point on a fixed test batch. Sommer and Paxson [7], Arp et al. [16] and Pendlebury et al. [26] "
  "show how closed-world assumptions, data snooping and time-agnostic splits inflate such results; dataset issues are documented for KDD Cup 99 [3], UNSW-NB15 [12], [13] and CIC-IDS2017 [14], [15]. "
  "For drift, Gama et al. survey adaptation methods [19], Transcend detects when malware-classifier decisions become unreliable [20], INSOMNIA keeps a NIDS up to date with active learning and label estimation [21], and "
  "Saerens et al. re-estimate class priors with EM [17]. Normal-only detectors such as Isolation Forest [9] and Kitsune [22] can in principle detect new attacks. None of the works reviewed treats the FAR as a target that "
  "must be maintained on deployment traffic under a fixed labelling budget, or reports how far the realised FAR departs from the chosen one; AFAC addresses that gap and is complementary to retraining. "
  "No systematic review was performed, so novelty is claimed only relative to these works.")

# ------------------------------------------------------------------ 3 method
H1("3. Adaptive False-Alarm Control")
P("A supervised detector gives each record x an attack score s(x) ∈ [0, 1] and a normal-only anomaly detector a score a(x); an alert is raised when s(x) > t. For a target α (1% or 5%) and normal records 𝒩,")
EQ("FAR(t) = |{x ∈ 𝒩 : s(x) > t}| / |𝒩|.", "(1)")
P("*Static calibration* sets t~0~ to the smallest t with FAR(t) ≤ α on validation normals. Validation quantities (t~0~, the attack detection profile R(t), anomaly thresholds) are computed on a 20% split in which identical feature "
  f"vectors are kept on the same side: on UNSW-NB15 only {pct(DG[U]['train_unique_share'])}% of training records are unique, and in a random split {pct(DG[U]['random_split_val_dup_share'])}% of validation records are exact copies "
  f"of fitting records, which inflates validation recall at t = 0.99 ({g(DG[U]['random_recall_at_0.99_val'],1)}% against {g(DG[U]['group_recall_at_0.99_val'],1)}% on the group split). Traffic is processed in windows of "
  "W = 2,000 records (Figure 1). For each window k, AFAC:")
NUM("**Alerts** on s(x) > t~k~, and in novel-attack mode also on a(x) > τ~k~ (logical OR); t~1~ = t~0~ with the anomaly branch off.")
NUM("**Audits** b·W records (b = 1% unless stated): 80% drawn from suspicious records (s(x) > 0.1 or a(x) above its 10%-validation-FAR threshold), 20% from the rest; record i in stratum j gets weight w~i~ = n~j~/m~j~.")
NUM(f"**Estimates** the FAR from audited normals 𝒜~N~ of the last K = 25 windows with the Horvitz–Thompson estimator [23]: F{H}(t) = Σ~i∈𝒜N~ w~i~·1[s(x~i~) > t] / Σ~i∈𝒜N~ w~i~.")
NUM(f"**Updates** t~k+1~ = min{{t : F{H}(t) ≤ α}} on a fine grid (if infeasible below 1, the threshold of minimal estimated FAR; at least 20 audited normals are required, otherwise t~0~ is kept).")
NUM(f"**Tests for novelty**: if the weighted detection rate d{H} of audited attacks at t = 0.5 is at least 0.10 below R(0.5) and a one-sided z-test (effective sample size) gives z < −2.33, the anomaly branch is switched on and t~k+1~ is chosen so that the combined rule meets α.")
P("In the pre-specified *AFAC*, τ gives α/2 FAR on validation normals; in the post-hoc *AFAC-v2* (Section 5.4), τ~k~ gives α/2 weighted FAR on audited normals. Audited records are excluded from all metrics and no unaudited "
  "test label is used. A label-free variant, solving A(t) = πR(t) + (1 − π)FAR(t) for FAR from the window's alert rate A(t), was rejected in preliminary analysis: on UNSW-NB15 an error of ±0.05 in the attack share π moves "
  f"the realised FAR from {g(DG[U]['labelfree_sensitivity']['+0.00']['far'])}% to {g(DG[U]['labelfree_sensitivity']['-0.05']['far'])}% or {g(DG[U]['labelfree_sensitivity']['+0.05']['far'])}%, and on the other datasets the estimate is negative even with the true π.")
FIG("figs/fig1_architecture.png", 0.482, 500, "AFAC architecture")
CAP("**Figure 1.** Detector with Adaptive False-Alarm Control. The offline part uses only the training file; online, each window's threshold is set from audited records of previous windows.", False)

# ------------------------------------------------------------------ 4 protocol
H1("4. Data and Protocol")
P("**Datasets** (Table 1). NSL-KDD [3] uses KDDTrain+ and KDDTest+; 17 test attack types (3,750 records) are absent from training. UNSW-NB15 uses the official partition [12], [13]. CIC-IDS2017 [14] uses the "
  "MachineLearningCVE flows with a temporal protocol: training on Monday and Wednesday (benign; DoS Hulk, GoldenEye, slowloris, Slowhttptest, Heartbleed), testing on the Friday-afternoon DDoS file in time order. "
  "Exact duplicate training rows were removed (1,222,621 → 1,113,575) and each seed draws a family-stratified sample of 300,000 rows. Only three of eight CIC-IDS2017 days could be obtained, and the release has known labelling problems [15].")
NUMBERS += ["3,750", "1,222,621", "1,113,575"]
rows = [
    ["Training records, fit / validation (mean)"] + [f"{ic(S[d]['meta']['n_fit'])} / {ic(S[d]['meta']['n_val'])}" for d in (N, U, C)],
    ["Attack share, training / test (%)"] + [f"{pct(S[d]['meta']['fit_attack_share']['mean'])} / {pct(S[d]['meta']['test_attack_share']['mean'])}" for d in (N, U, C)],
    ["Test records (attacks of unseen types)", "22,544 (3,750)", "82,332 (none)", "225,745 (128,027)"],
    ["Features (encoded columns)", "41 (122)", "42 (196)", "68 numeric"],
    ["Unique training feature vectors (%)", pct(DG[N]['train_unique_share']), pct(DG[U]['train_unique_share']), pct(DG[C]['train_unique_share'])],
    ["Train-vs-test domain classifier AUC", g(DG[N]['domain_auc'], 3), g(DG[U]['domain_auc'], 3), g(DG[C]['domain_auc'], 3)],
]
NUMBERS += ["22,544", "82,332", "225,745", "128,027"]
CAP("**Table 1.** Datasets. The domain classifier (gradient boosting, 3-fold) separates 60,000 training from 60,000 test records; 0.5 would mean no detectable shift.")
TAB(dict(type="table", header=["", N, U, C], widths=[3.4, 1.8, 1.8, 1.8], rows=rows, size=15))
P("**Models.** Categorical fields are one-hot encoded and numeric fields standardised with training statistics (CIC-IDS2017: signed log transform first). Logistic Regression, Linear SVM, KNN (k = 5), Decision Tree, Random Forest (RF, "
  "100 trees) [8], XGBoost (300 trees, depth 8) [18] and an MLP (128–64) are trained on the fitting part with scikit-learn 1.9.1 [10] and XGBoost 3.4.1; an Isolation Forest (IF, 200 trees) [9] and an autoencoder (64–16–64) "
  "are trained on normal records with a 1% validation-FAR threshold, plus the RF + IF hybrid of the earlier version. Hyper-parameters were not tuned.")
P("**Streams and comparators.** FAR control is evaluated for Random Forest and XGBoost on the NSL-KDD and UNSW-NB15 test sets in random order, on a prevalence-drift reordering (phases with 10%, 80% and 30% attacks) and on the "
  "CIC-IDS2017 Friday file in time order. Comparators: default threshold 0.5, static calibration, EM prior adjustment [17], uniform audit (same budget, unstratified, no trigger), AFAC without trigger, and an oracle threshold "
  "computed from all test labels.")
P("**Statistics and reproducibility.** Ten seeds (0–9) vary the split, models, stream order and audit draws; results are means with 95% t-intervals. Paired seeds are compared with the two-sided Wilcoxon signed-rank test [24] "
  "(smallest attainable p = 0.002), with Holm correction [25] within four families of six tests stated before testing. AFAC was developed on NSL-KDD and UNSW-NB15, whose results were known; the CIC-IDS2017 run was executed once "
  "with fixed settings as a confirmatory test, and AFAC-v2 was written afterwards. AFAC-v2 was then frozen and validated on five further CIC-IDS2017 days (Section 5.5) under a protocol whose text, success criteria and code hashes were recorded before any model was applied to those days. All numbers are written to JSON with input checksums and checked automatically against this manuscript; re-running AFAC inside the v2 "
  "script reproduced all 30 reference runs exactly.")

# ------------------------------------------------------------------ 5 results
H1("5. Results")
H2("5.1 Baseline detectors")
models = [("LR", "Logistic Regression"), ("LinearSVM", "Linear SVM"), ("KNN", "KNN (k = 5)"), ("DT", "Decision Tree"), ("RF", "Random Forest"),
          ("XGB", "XGBoost"), ("MLP", "MLP"), ("IF@1%", "Isolation Forest"), ("AE@1%", "Autoencoder"), ("RF+IF hybrid", "RF + IF hybrid")]
rows = []
for k, lab in models:
    r = [lab]
    for ds in (N, U, C):
        b = S[ds]["baseline"][k]
        r += [m(b["rec"], 1), m(b["far"], 2), m(b["f1"], 1), "–" if b.get("pr_auc") is None else m(b["pr_auc"], 3)]
    rows.append(r)
P(f"Table 2 summarises the detectors at their default operating points. On **NSL-KDD**, Decision Tree and XGBoost are most accurate ({bl(N,'DT','acc')}% and {bl(N,'XGB','acc')}%), but every supervised model misses a third of "
  f"the attacks, mainly R2L (Random Forest recall {bl(N,'RF','rec_R2L',1)}%) and unseen types ({bl(N,'RF','rec_unseen',1)}% against {bl(N,'RF','rec_seen',1)}% on seen types). On **UNSW-NB15** recall exceeds 95% but the FAR is "
  f"{bl(U,'XGB','far',1)}–{bl(U,'LinearSVM','far',1)}%. On **CIC-IDS2017** the Random Forest is {m(S[C]['baseline']['RF']['val']['acc'])}% accurate on validation data but detects only {bl(C,'RF','rec',1)}% of the unseen DDoS flows, "
  f"and the Isolation Forest calibrated for 1% FAR flags {bl(C,'IF@1%','far',1)}% of Friday's benign flows.")
CAP("**Table 2.** Default operating points: recall, FAR (%), F1 (%) and PR-AUC, means over ten seeds (95% CIs in the supplementary summary.json).")
TAB(dict(type="table", header=["Model", "NSL Rec", "NSL FAR", "NSL F1", "NSL PR-AUC", "UNSW Rec", "UNSW FAR", "UNSW F1", "UNSW PR-AUC", "CIC Rec", "CIC FAR", "CIC F1", "CIC PR-AUC"],
         widths=[2.1] + [0.82] * 12, rows=rows, size=13))

H2("5.2 Sources of false alarms")
P(f"On UNSW-NB15, {pct(DG[U]['fa_sttl254_share'])}% of the Random Forest's false alarms (seed 0) have source TTL 254, a value carried by {pct(DG[U]['sttl254_share_attacks_train'])}% of training attacks but only "
  f"{pct(DG[U]['sttl254_share_normals_train'])}% of training normals, whereas {pct(DG[U]['sttl254_share_normals_test'])}% of test normals carry it. The normal traffic moves into a region the training data associate with attacks, "
  "a class-conditional shift that prior correction cannot repair. On CIC-IDS2017 the shift is across days: the Isolation Forest threshold that gives "
  f"{g(DG[C]['IF_far_val_0.01'],2)}% FAR on Monday/Wednesday validation traffic gives {g(DG[C]['IF_far_test_0.01'],1)}% on Friday, whereas it transfers on NSL-KDD ({g(DG[N]['IF_far_test_0.01'],2)}%) and UNSW-NB15 "
  f"({g(DG[U]['IF_far_test_0.01'],2)}%). The domain classifier of Table 1 separates training from test data on all three datasets.")

H2("5.3 False-alarm control")
meths = [("default", "Default threshold 0.5"), ("static", "Static calibration"), ("em_prior", "EM prior adjustment [17]"), ("uniform_audit@0.01", "Uniform audit"),
         ("afac_nonovelty@0.01", "AFAC without trigger"), ("afac@0.01", "AFAC (pre-specified)"), ("afac_v2@0.01", "AFAC-v2 (post hoc)"), ("oracle", "Oracle (test labels)")]
rows, hl = [], []
for det, mlist in [("RF", meths), ("XGB", [x for x in meths if x[0] in ("static", "uniform_audit@0.01", "afac@0.01", "afac_v2@0.01", "oracle")])]:
    rows.append([{"RF": "Random Forest", "XGB": "XGBoost"}[det]])
    for meth, lab in mlist:
        r = [lab]
        for ds in (N, U, C):
            for a in (0.01, 0.05):
                v = S[ds]["far_control"][K(ds, a, det)][meth]
                r.append(f"{m(v['far'], 2)} / {m(v['rec'], 1)}")
        if meth == "afac_v2@0.01": hl.append(len(rows))
        rows.append(r)
P("Table 3 and Figure 2 compare the threshold methods. Static calibration overshoots everywhere: for a 1% target the Random Forest reaches "
  f"{fc(N,K(N,0.01),'static','far')}% FAR on NSL-KDD, {fc(U,K(U,0.01),'static','far')}% on UNSW-NB15 and {fc(C,K(C,0.01),'static','far')}% on CIC-IDS2017, and its high recall is a consequence of that overshoot. "
  f"EM prior adjustment stays near the default point (UNSW-NB15: {fc(U,K(U,0.01),'em_prior','far')}% FAR). With a 1% audit, AFAC-v2 reaches {fc(U,K(U,0.01),'afac_v2@0.01','far')}% FAR at "
  f"{fc(U,K(U,0.01),'afac_v2@0.01','rec',1)}% recall on UNSW-NB15 for a 1% target (oracle {fc(U,K(U,0.01),'oracle','far')}% at {fc(U,K(U,0.01),'oracle','rec',1)}%), and {fc(U,K(U,0.05),'afac_v2@0.01','far')}% at "
  f"{fc(U,K(U,0.05),'afac_v2@0.01','rec',1)}% for 5%. This answers the 27% false alarm rate of the earlier version: the operator, not the training data, now chooses the point on the trade-off. "
  f"On CIC-IDS2017 AFAC-v2 gives {fc(C,K(C,0.01),'afac_v2@0.01','far')}% and {fc(C,K(C,0.05),'afac_v2@0.01','far')}% with recall close to the oracle. On NSL-KDD the target is approached but not met "
  f"({fc(N,K(N,0.01),'afac_v2@0.01','far')}% for 1%): the stream has only twelve windows, and the second half reaches {fc(N,K(N,0.01),'afac_v2@0.01',('2ndhalf','far'))}%. "
  f"XGBoost behaves alike; for CIC-IDS2017 at 1%, its static threshold already gives {fc(C,K(C,0.01,'XGB'),'static','far')}%.")
CAP("**Table 3.** Realised FAR / recall (%) under threshold-control methods, means over ten seeds; audit methods label 1% of the traffic, and audited records are excluded. Highlighted: proposed method.")
TAB(dict(type="table", header=["Method", "NSL 1%", "NSL 5%", "UNSW 1%", "UNSW 5%", "CIC 1%", "CIC 5%"], widths=[2.3, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25],
         rows=rows, highlight=hl, size=14))
FIG("figs/fig2_far_recall.png", 0.571, 500, "FAR vs recall")
CAP("**Figure 2.** Realised FAR (symmetric log scale) against recall for the Random Forest; error bars are 95% CIs over ten seeds; dotted lines mark the target.", False)

H2("5.4 Confirmatory CIC-IDS2017 run and AFAC-v2")
nw = S[C]["far_control"][K(C, 0.01)]["afac@0.01"]["novel_windows"]["mean"]
P(f"In the pre-specified run the novelty trigger fired in {g(nw,0)} of 113 windows, correctly: the Random Forest detects {bl(C,'RF','rec_unseen',1)}% of the unseen DDoS flows against more than 99% of validation attacks. "
  f"But the anomaly branch, calibrated on other days, flooded the analysts, and AFAC reached {fc(C,K(C,0.01),'afac@0.01','far')}% FAR for a 1% target and {fc(C,K(C,0.05),'afac@0.01','far')}% for 5%, worse than without the trigger "
  f"({fc(C,K(C,0.01),'afac_nonovelty@0.01','far')}% and {fc(C,K(C,0.05),'afac_nonovelty@0.01','far')}%). AFAC-v2 measures the branch on audited traffic and restores {fc(C,K(C,0.01),'afac_v2@0.01','far')}% and "
  f"{fc(C,K(C,0.05),'afac_v2@0.01','far')}% (Figure 3), but it detects no more DDoS flows, because the Isolation Forest does not separate DDoS from Friday benign traffic; being post hoc, these numbers are not confirmatory. "
  f"On NSL-KDD, where the Isolation Forest responds to the new types, the trigger raised unseen-type recall from {fc(N,K(N,0.01),'afac_nonovelty@0.01','rec_unseen',1)}% to {fc(N,K(N,0.01),'afac_v2@0.01','rec_unseen',1)}% "
  "for a 1% target; on UNSW-NB15, with no new categories, it never fired.")
FIG("figs/fig3_cic_trace.png", 0.556, 440, "CIC trace")
CAP("**Figure 3.** CIC-IDS2017 Friday stream in time order (Random Forest, 1% target, seed 0): attack share (top) and FAR per 2,000-flow window (bottom).", False)

SENS = IND["sensitivity"]
W = {0: "none", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six"}
def srange(ds, a, k, d):
    v = [SENS[ds][f"{a}|{sh}"][k]["mean"] for sh in (0.25, 0.5, 0.75)]
    return f"{g(min(v), d)}–{g(max(v), d)}"
P("**Why the revision is a correction and not a tuning step.** Four points support treating AFAC-v2 as the intended method rather than as a fit to CIC-IDS2017. "
  "(i) The cause of the failure was established independently of AFAC-v2's results: the anomaly threshold set for 1% FAR on Monday/Wednesday validation traffic gives "
  f"{g(DG[C]['IF_far_test_0.01'],1)}% on Friday (Section 5.2), so the pre-specified design relied on exactly the kind of offline calibration that AFAC exists to replace. "
  "(ii) The revision introduces no new mechanism: the same audited Horvitz–Thompson estimate that sets the supervised threshold now also sets the anomaly threshold, which makes the method internally consistent. "
  "(iii) It adds no tuned parameter; the half-and-half split of the FAR budget is inherited from the pre-specified version, and varying it from 0.25 to 0.75 changes the realised FAR on CIC-IDS2017 for a 1% target only within "
  f"{srange('cic',0.01,'far',2)}% (NSL-KDD {srange('nsl',0.01,'far',2)}%, UNSW-NB15 {srange('unsw',0.01,'far',2)}%; ten seeds each). "
  "(iv) Where the offline anomaly threshold does transfer, the revision changes almost nothing: on UNSW-NB15 the results are identical because the trigger never fires, and on NSL-KDD the FAR for a 1% target moves from "
  f"{fc(N,K(N,0.01),'afac@0.01','far')}% to {fc(N,K(N,0.01),'afac_v2@0.01','far')}%, within the confidence intervals. Because these arguments are made after the fact, AFAC-v2 was then tested on data it had never seen (Section 5.5).")

H2("5.5 Independent validation on five unseen CIC-IDS2017 days")
ID = IND["days"]; DAYS = [("Tuesday", "Tuesday"), ("Thursday-AM", "Thursday morning"), ("Thursday-PM", "Thursday afternoon"), ("Friday-AM", "Friday morning"), ("Friday-PortScan", "Friday PortScan")]
ATT = {"Tuesday": "FTP/SSH-Patator", "Thursday-AM": "Web attacks", "Thursday-PM": "Infiltration", "Friday-AM": "Bot", "Friday-PortScan": "PortScan"}
EP = IND["endpoints"]
P("The protocol was fixed before any model was applied to the five remaining CIC-IDS2017 days (Tuesday, Thursday morning and afternoon, Friday morning and the Friday PortScan file), which contain attack types absent "
  "from the Monday/Wednesday training data. Training, settings and seeds were identical to Section 5.3, and each day was streamed in time order. The pre-stated criteria for the Random Forest were S1, AFAC-v2 significantly closer to the target "
  "than static calibration (Holm-adjusted Wilcoxon p < 0.05) in at least 8 of the 10 day–target combinations, and S2, a mean realised FAR of at most the target plus one point in at least 8 of 10. "
  "One deviation is recorded: the first run ran out of memory while loading the data, before any model was trained, and the loading code was changed to process one day at a time; on a previously used file the "
  "output was byte-identical before and after the change.")
P(f"**S2 was met** (10 of 10 for both detectors): for the Random Forest, AFAC-v2 stayed between {g(min(ID[d]['RF|0.01|afac_v2']['far']['mean'] for d,_ in DAYS),2)}% and "
  f"{g(max(ID[d]['RF|0.01|afac_v2']['far']['mean'] for d,_ in DAYS),2)}% FAR for a 1% target and at most {g(max(ID[d]['RF|0.05|afac_v2']['far']['mean'] for d,_ in DAYS),2)}% for 5% (Table 4). "
  f"**S1 was not met** ({EP['RF']['S1_count']} of 10 for the Random Forest, {EP['XGB']['S1_count']} of 10 for XGBoost). On Tuesday and Thursday afternoon, where the traffic shifted, static calibration overshot "
  f"({m(ID['Tuesday']['RF|0.01|static']['far'])}% and {m(ID['Thursday-PM']['RF|0.01|static']['far'])}% for a 1% target) and AFAC-v2 corrected it in all four comparisons. On the other three days static calibration already "
  f"met the target; of these six comparisons AFAC-v2 was significantly closer in {W[sum(1 for k,v in EP['RF']['rows'].items() if k.split('|')[0] in ('Thursday-AM','Friday-AM','Friday-PortScan') and v['p_holm']<0.05 and v['err_diff']['mean']<0)]} (both at 5%, by moving the FAR up towards the target), "
  f"not significantly different in {W[sum(1 for k,v in EP['RF']['rows'].items() if k.split('|')[0] in ('Thursday-AM','Friday-AM','Friday-PortScan') and v['p_holm']>=0.05)]}, and significantly further away in one, Friday PortScan at 1% "
  f"({m(ID['Friday-PortScan']['RF|0.01|afac_v2']['far'])}% against {m(ID['Friday-PortScan']['RF|0.01|static']['far'])}%). Criterion S1 thus measures whether a shift occurred as much as whether AFAC works; "
  "this reading is post hoc, and the criterion is reported as failed.")
P("Two further results qualify the method. Detection at low FAR is limited by the detector: on Tuesday at a 1% target, AFAC-v2 detects "
  f"{m(ID['Tuesday']['RF|0.01|afac_v2']['rec'],1)}% of attacks, as does the oracle threshold ({m(ID['Tuesday']['RF|0.01|oracle']['rec'],1)}%); the static threshold's {m(ID['Tuesday']['RF|0.01|static']['rec'],1)}% recall is bought with "
  f"{m(ID['Tuesday']['RF|0.01|static']['far'])}% FAR. The novelty trigger fired often (Tuesday: {m(ID['Tuesday']['RF|0.01|afac_v2']['novel_windows'],0)} of {ID['Tuesday']['RF|0.01|afac_v2']['windows']} windows), but the anomaly branch "
  f"detected little and used part of the FAR budget, lowering recall on Tuesday at 5% from {m(ID['Tuesday']['RF|0.05|afac_nonovelty']['rec'],1)}% without the trigger to {m(ID['Tuesday']['RF|0.05|afac_v2']['rec'],1)}%. "
  f"On these days the Isolation Forest threshold did transfer ({g(min(ID[d]['IF_far']['mean'] for d,_ in DAYS),1)}–{g(max(ID[d]['IF_far']['mean'] for d,_ in DAYS),1)}% FAR for a 1% target), so AFAC and AFAC-v2 gave almost identical results. "
  "On unseen days the benefit of AFAC comes from threshold recalibration; the anomaly branch has not shown a consistent benefit outside NSL-KDD.")
irows = []
for d, lab in DAYS:
    T = ID[d]; r = [f"{lab} ({ATT[d]}; {T['n_attack']:,} / {T['n']:,})"]
    NUMBERS.extend([f"{T['n_attack']:,}", f"{T['n']:,}"])
    for a in ["0.01", "0.05"]:
        for mm in ["static", "afac_v2", "oracle"]:
            v = T[f"RF|{a}|{mm}"]; r.append(f"{m(v['far'],2)} / {m(v['rec'],1)}")
    irows.append(r)
CAP("**Table 4.** Frozen independent validation, Random Forest: realised FAR / recall (%), means over ten seeds. In brackets: attack type; attack records / all records. Thursday afternoon has only 36 attacks, so its recall is not interpreted.")
TAB(dict(type="table", header=["Test day", "Static 1%", "AFAC-v2 1%", "Oracle 1%", "Static 5%", "AFAC-v2 5%", "Oracle 5%"], widths=[3.0, 1.05, 1.05, 1.05, 1.05, 1.05, 1.05], rows=irows, size=13))

H2("5.6 Statistical significance and audit budget")
fam_rows = []
for det in ["RF", "XGB"]:
    for h, lab in [("H1", "H1 |FAR − target|, v2 − static"), ("H2", "H2 Recall, v2 − static"), ("H3", "H3 |FAR − target|, v2 − uniform"), ("H4", "H4 Recall, v2 − no trigger")]:
        key = [x for x in F if x.startswith(det + "|" + h)][0]
        row = [f"{det}: {lab}"]
        for ds in (N, U, C):
            for a in (0.01, 0.05):
                r = F[key][f"{ds}|{a}"]; row.append(mci(r["diff"], 1) + ("*" if r["p_holm"] < 0.05 else ""))
        fam_rows.append(row)
P("Table 5 reports the pre-stated families. AFAC-v2 is closer to the target than static calibration in all six Random Forest comparisons (H1, Holm-adjusted p = 0.012) and five of six for XGBoost, with lower recall in all (H2). "
  "Against uniform auditing at the same budget (H3) no Random Forest difference survives correction, and for XGBoost on CIC-IDS2017 uniform auditing is slightly better, so stratification brought no measurable gain. "
  "The trigger (H4) raises recall on NSL-KDD at 1%, is neutral on UNSW-NB15 and costs one to two points on CIC-IDS2017. "
  f"Raising the budget from 1% to 2% brings the FAR for a 5% target to {fc(N,K(N,0.05),'afac_v2@0.02','far')}% (NSL-KDD) and {fc(U,K(U,0.05),'afac_v2@0.02','far')}% (UNSW-NB15); at 0.5%, NSL-KDD stays near the static level "
  f"({fc(N,K(N,0.05),'afac_v2@0.005','far')}%). A 1% budget means about {ic(S[U]['far_control'][K(U,0.01)]['afac_v2@0.01']['labels_used'])} labelled UNSW-NB15 records.")
CAP("**Table 5.** Paired differences, mean ± 95% CI over ten seeds (percentage points). * Holm-adjusted Wilcoxon p < 0.05 within each family of six; negative H1/H3 values favour AFAC-v2.")
TAB(dict(type="table", header=["Family", "NSL 1%", "NSL 5%", "UNSW 1%", "UNSW 5%", "CIC 1%", "CIC 5%"], widths=[2.6, 1.15, 1.15, 1.15, 1.15, 1.15, 1.15], rows=fam_rows, size=13))

H2("5.7 Robustness")
P(f"**Prevalence drift.** In the three-phase streams AFAC-v2 gives {fc(U,KD(U,0.01),'afac_v2@0.01','far')}% FAR ({fc(U,KD(U,0.01),'afac_v2@0.01','rec',1)}% recall) on UNSW-NB15 and "
  f"{fc(N,KD(N,0.01),'afac_v2@0.01','far')}% ({fc(N,KD(N,0.01),'afac_v2@0.01','rec',1)}%) on NSL-KDD for a 1% target, close to the shuffled streams; the CIC-IDS2017 stream itself moves from 0% to over 90% attacks and back.")
vals_f = [IM[U][c]["afac@5%"]["far"]["mean"] for c in IM[U] if c != "n_seeds"]; vals_r = [IM[U][c]["afac@5%"]["rec"]["mean"] for c in IM[U] if c != "n_seeds"]
P(f"**Class imbalance.** When attacks are cut to 1% of the fitting data, the default Random Forest becomes conservative (UNSW-NB15 FAR {im(U,'0.01|plain','default','far',2)}%, recall {im(U,'0.01|plain','default','rec')}%), "
  f"and class weighting changes this only partly (recall {im(U,'0.01|balanced','default','rec')}%). With AFAC at a 5% target, the FAR stays at {g(min(vals_f))}–{g(max(vals_f))}% and recall at "
  f"{g(min(vals_r),1)}–{g(max(vals_r),1)}% across all six imbalance settings (5 seeds), because the threshold is set on deployment traffic; on NSL-KDD (10 seeds) PR-AUC falls only from "
  f"{im(N,'orig|plain','default','pr_auc',3)} to {im(N,'0.01|plain','default','pr_auc',3)}.")
P("**Unseen attack families** (Table 6, one family removed from training, five seeds). On NSL-KDD the Random Forest detects only "
  f"{lo(N,'Probe','RF')}% of held-out Probe and {lo(N,'DoS','RF')}% of held-out DoS records; with the trigger, AFAC-v2 at a 5% target reaches {lo(N,'Probe','AFAC-v2@5%')}% and {lo(N,'DoS','AFAC-v2@5%')}% "
  f"(without trigger {lo(N,'Probe','AFAC-nonovelty@5%')}% and {lo(N,'DoS','AFAC-nonovelty@5%')}%); R2L stays near {lo(N,'R2L','AFAC-v2@5%',)}%. On UNSW-NB15 the default model detects almost every held-out family only "
  f"because it over-alerts: at 1% FAR, held-out Generic recall is {lo(U,'Generic','AFAC-v2@1%')}% and Reconnaissance {lo(U,'Reconnaissance','AFAC-v2@1%')}%. Controlling false alarms exposes, rather than causes, the weak generalisation.")
lrows = []
for ds in (N, U):
    lrows.append([ds])
    for f_ in [x for x in LO[ds] if x != "n_seeds"]:
        v = LO[ds][f_]
        lrows.append([f_, m(v["n_test_heldout"], 0), f"{m(v['RF']['rec_heldout'],1)} / {m(v['RF']['far'],1)}", m(v["AFAC-nonovelty@5%"]["rec_heldout"], 1),
                      f"{m(v['AFAC-v2@5%']['rec_heldout'],1)} / {m(v['AFAC-v2@5%']['far'],1)}", f"{m(v['AFAC-v2@1%']['rec_heldout'],1)} / {m(v['AFAC-v2@1%']['far'],1)}"])
CAP("**Table 6.** Leave-one-family-out: recall on the held-out family / overall FAR (%), means over five seeds, 1% audit budget.")
TAB(dict(type="table", header=["Held-out family", "Test records", "RF (0.5)", "AFAC no trigger 5%: recall", "AFAC-v2, 5% target", "AFAC-v2, 1% target"],
         widths=[1.8, 1.1, 1.4, 1.6, 1.6, 1.6], rows=lrows, size=13))

H2("5.8 Feature selection and published results")
fsN, fsU = FS[N]["runs"], FS[U]["runs"]
P("Re-running the earlier grouped permutation-importance selection [11] on the duplicate-aware split confirms the NSL-KDD result: five features give "
  f"{m(fsN['val_top5']['acc'])}% accuracy against {m(fsN['all']['acc'])}% with all features, but a FAR of {m(fsN['val_top5']['far'])}% against {m(fsN['all']['far'])}%. On UNSW-NB15 the five-feature subset now gives "
  f"{m(fsU['val_top5']['acc'])}% against {m(fsU['all']['acc'])}% (earlier: 87.1% → 78.2%), because the ranking changes without duplicates. PR-AUC is lower for every five-feature subset "
  f"({m(fsN['val_top5']['pr_auc'],3)} vs {m(fsN['all']['pr_auc'],3)} on NSL-KDD), so compact feature sets shift the operating point rather than improve the ranking and are no substitute for threshold control. "
  f"The published accuracies above 95% [4]–[6] contrast with {bl(N,'RF','acc')}% for the Random Forest on KDDTest+; the same model reaches {m(S[N]['baseline']['RF']['val']['acc'])}% on an in-distribution validation split, "
  "which illustrates how much the evaluation split matters. None of the cited studies reports the realised FAR against a target, so the main result has no published counterpart.")

H2("5.9 Limitations")
P("AFAC needs a 1% audit, and real analyst labels are noisy and delayed, whereas correct labels one window later are assumed here. It recalibrates but does not retrain, so when the ranking itself is poor (UNSW-NB15 Generic held out) "
  "no threshold gives both low FAR and high detection. The trigger relies on an anomaly detector that responds to the new attacks, which held on NSL-KDD but not for DDoS on CIC-IDS2017. Stratified sampling brought no gain. "
  "The frozen validation used new days of the same dataset and the same training days, so evaluation on a different dataset and network remains necessary. CIC-IDS2017 training data were subsampled, the NSL-KDD stream is short, "
  "default hyper-parameters were used and the evaluation is offline.")

# ------------------------------------------------------------------ 6 conclusion
H1("6. Conclusion")
P(f"Thresholds calibrated on validation data did not hold the FAR of any detector near its target on any of three benchmarks (up to {fc(C,K(C,0.05),'static','far',1)}% for a 5% target). AFAC, which recalibrates the threshold "
  f"from a 1% audit, kept it far closer, significantly so in 11 of 12 pre-stated comparisons, and cut the Random Forest's false alarms on UNSW-NB15 from {bl(U,'RF','far',1)}% to {fc(U,K(U,0.05),'afac_v2@0.01','far',1)}% at "
  f"{fc(U,K(U,0.05),'afac_v2@0.01','rec',1)}% recall. The lower recall is the price of the FAR the operator chose. The confirmatory CIC-IDS2017 run showed that an anomaly branch calibrated offline can make matters worse "
  "when normal traffic changes between days; measuring it on audited traffic repaired the false alarms but not the detection of new DDoS attacks. A frozen validation on five unseen days confirmed that AFAC-v2 keeps the FAR "
  "within one point of its target where static thresholds fail, but also that it brings no gain where they do not, and that the anomaly branch has not yet earned its place outside NSL-KDD. Future work should combine threshold control with retraining from audited "
  "records, model label noise and delay, and evaluate on a different dataset and network with a protocol fixed in advance.")
P("**Data and code availability.** NSL-KDD: github.com/defcom17/NSL_KDD; UNSW-NB15: github.com/Nir-J/ML-Projects; CIC-IDS2017 MachineLearningCVE files: Git LFS objects of github.com/antiantimailed-dotcom/CSCI6330-Detector-Project "
  "and github.com/SHUBHAMRAWAT-25/DDOS-attack-detection-using-random-forest-algorithm and github.com/bibhash074/Machine-Learning (remaining days); these are public mirrors whose SHA-256 checksums match the Git LFS object IDs of a second, independent mirror. "
  f"Code, configuration, frozen validation protocol and all result files: {CFG['repo']}.")

# ------------------------------------------------------------------ references (unchanged list)
# ---- renumber citations in order of first appearance (IEEE style)
import build_paper_refs
GRP = re.compile(r"\[\d+\](?:\s*[–-]\s*\[\d+\])?(?:,\s*\[\d+\](?:\s*[–-]\s*\[\d+\])?)*")
def nums_in(g_):
    out = []
    for a_, b_ in re.findall(r"\[(\d+)\](?:\s*[–-]\s*\[(\d+)\])?", g_):
        out += list(range(int(a_), int(b_ or a_) + 1))
    return out
def strings(bl_):
    for k in ("text", "note"):
        if k in bl_: yield bl_, k, None
    if bl_.get("type") == "table":
        for i, _ in enumerate(bl_["header"]): yield bl_["header"], i, None
        for row in bl_["rows"]:
            for i, _ in enumerate(row): yield row, i, None
order = []
for bl_ in B:
    for obj, k, _ in strings(bl_):
        for g_ in GRP.findall(str(obj[k])):
            for n in nums_in(g_):
                if n not in order: order.append(n)
assert sorted(order) == list(range(1, len(build_paper_refs.REFS) + 1)), sorted(order)
new = {old: i + 1 for i, old in enumerate(order)}
def fmt(ns):
    ns = sorted(set(ns)); parts = []; i = 0
    while i < len(ns):
        j = i
        while j + 1 < len(ns) and ns[j + 1] == ns[j] + 1: j += 1
        parts.append(f"[{ns[i]}]" if j == i else (f"[{ns[i]}], [{ns[j]}]" if j == i + 1 else f"[{ns[i]}]–[{ns[j]}]")); i = j + 1
    return ", ".join(parts)
for bl_ in B:
    for obj, k, _ in strings(bl_):
        obj[k] = GRP.sub(lambda mm: fmt([new[n] for n in nums_in(mm.group(0))]), str(obj[k]))
H1("References")
for i, old in enumerate(order, 1):
    B.append(dict(type="ref", text=f"[{i}]\t{build_paper_refs.REFS[old - 1]}"))

json.dump(dict(blocks=B, doc_title="Adaptive False-Alarm Control for ML-based NIDS", fontSize=22, line=264, margin=1260),
          open("paper_spec_final.json", "w"), ensure_ascii=False)
json.dump(NUMBERS, open("paper_numbers.json", "w"))
print("blocks", len(B), "numbers", len(NUMBERS))
