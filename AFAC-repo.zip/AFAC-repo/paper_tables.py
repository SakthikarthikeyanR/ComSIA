"""Table builders and number helpers for the manuscript; every number comes from results/summary.json or
results/diag.json. Each emitted numeric cell is also logged in NUMBERS for verify_paper.py."""
import json

S = json.load(open("results/summary.json"))
DG = json.load(open("results/diag.json"))
NUMBERS = []          # (label, value-string) for verification
DS3 = [("NSL-KDD", "shuffled"), ("UNSW-NB15", "shuffled"), ("CIC-IDS2017", "temporal")]


def _get(d, path):
    for p in path:
        d = d[p]
    return d


def num(x, d=2):
    return f"{x:.{d}f}"


def mci(stat, d=2, ci=True):
    """'mean ± ci' from a ci-dict."""
    if stat is None: return "–"
    s = f"{stat['mean']:.{d}f}" + (f" ± {stat['ci']:.{d}f}" if ci else "")
    NUMBERS.append(s); return s


def m(stat, d=2):
    if stat is None: return "–"
    s = f"{stat['mean']:.{d}f}"; NUMBERS.append(s); return s


def bl(ds, model, k, d=2, ci=False):
    v = S[ds]["baseline"][model].get(k)
    if k in ("pr_auc", "roc_auc") and v is not None:
        v = dict(mean=v["mean"], ci=v["ci"]); d = 3
    return mci(v, d, ci) if ci else m(v, d)


def fc(ds, key, meth, k, d=2, ci=False):
    v = S[ds]["far_control"][key][meth]
    v = v[k] if not isinstance(k, tuple) else v[k[0]][k[1]]
    return mci(v, d, ci) if ci else m(v, d)


MODELS = [("LR", "Logistic Regression"), ("LinearSVM", "Linear SVM"), ("KNN", "KNN (k = 5)"), ("DT", "Decision Tree"),
          ("RF", "Random Forest"), ("XGB", "XGBoost"), ("MLP", "MLP (128-64)"), ("IF@1%", "Isolation Forest (1% val. FAR)"),
          ("AE@1%", "Autoencoder (1% val. FAR)"), ("RF+IF hybrid", "RF + IF hybrid (OR)")]


def table_baseline(ds):
    rows = []
    for k, lab in MODELS:
        b = S[ds]["baseline"][k]
        pr = "–" if b.get("pr_auc") is None else mci(b["pr_auc"], 3, False)
        rows.append([lab, mci(b["acc"], 2), mci(b["prec"], 2, False), mci(b["rec"], 2), mci(b["f1"], 2, False), mci(b["far"], 2), pr])
    return dict(type="table", header=["Model", "Accuracy", "Precision", "Recall", "F1", "FAR", "PR-AUC"],
                widths=[3.0, 1.6, 1.1, 1.6, 1.1, 1.6, 1.0], rows=rows)


METHODS = [("default", "Default threshold 0.5"), ("static", "Static validation calibration"), ("em_prior", "EM prior adjustment [17]"),
           ("uniform_audit@0.01", "Uniform audit, 1% budget"), ("afac_nonovelty@0.01", "AFAC without novelty trigger, 1%"),
           ("afac@0.01", "AFAC (pre-specified), 1%"), ("afac_v2@0.01", "AFAC-v2 (post hoc), 1%"), ("oracle", "Oracle threshold (uses test labels)")]


def table_far_control(det="RF", alphas=(0.01, 0.05), cols=("far", "rec", "prec", "f1")):
    rows = []; hl = []
    names = {"far": "FAR", "rec": "Recall", "prec": "Precision", "f1": "F1"}
    for ds, order in DS3:
        for alpha in alphas:
            key = f"{det}|{order}|{alpha}"
            rows.append([f"{ds} ({order} stream), target FAR {int(alpha*100)}%"])
            for meth, lab in METHODS:
                if meth not in S[ds]["far_control"][key]: continue
                r = [lab] + [mci(S[ds]["far_control"][key][meth][c], 2 if c == "far" else 1, c in ("far", "rec")) for c in cols]
                if meth in ("afac@0.01", "afac_v2@0.01"): hl.append(len(rows))
                rows.append(r)
    return dict(type="table", header=["Method"] + [names[c] for c in cols], widths=[3.6, 1.7, 1.7, 1.2, 1.2], rows=rows, highlight=hl, size=16)
