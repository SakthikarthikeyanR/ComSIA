"""Pre-specified analysis of the independent validation (PROTOCOL_independent_validation.md) and of the
AFAC-v2 sensitivity runs. -> results/indep_summary.json"""
import json, glob, os
import numpy as np
from summarize import ci, wilcoxon, holm

RES = "results"
runs = [json.load(open(f)) for f in sorted(glob.glob(f"{RES}/indep_seed*.json"))]
DAYS = list(runs[0]["days"])
METH = ["static", "uniform_audit", "afac_nonovelty", "afac", "afac_v2", "oracle"]
O = dict(n_seeds=len(runs), days={}, endpoints={})
for day in DAYS:
    d0 = runs[0]["days"][day]
    T = O["days"][day] = dict(n=d0["n"], n_attack=d0["n_attack"], attack_types=d0["attack_types"],
                              IF_far=ci([r["days"][day]["IF@1%"]["far"] for r in runs]))
    for det in ["RF", "XGB"]:
        T[f"{det}|default"] = {k: ci([r["days"][day][f"{det}|default"][k] for r in runs]) for k in ["far", "rec", "prec"]}
        T[f"{det}|default"]["pr_auc"] = ci([r["days"][day][f"{det}|default"].get("pr_auc") for r in runs])
        for a in ["0.01", "0.05"]:
            for m in METH:
                v = [r["days"][day][f"{det}|{a}"][m] for r in runs]
                T[f"{det}|{a}|{m}"] = {k: ci([x[k] for x in v]) for k in ["far", "rec", "prec", "f1"]}
                if "novel_windows" in v[0]:
                    T[f"{det}|{a}|{m}"]["novel_windows"] = ci([x["novel_windows"] for x in v]); T[f"{det}|{a}|{m}"]["windows"] = v[0]["windows"]
# endpoints
for det in ["RF", "XGB"]:
    E1, rows = {}, {}
    for day in DAYS:
        for a in ["0.01", "0.05"]:
            al = float(a) * 100
            e_v2 = [abs(r["days"][day][f"{det}|{a}"]["afac_v2"]["far"] - al) for r in runs]
            e_st = [abs(r["days"][day][f"{det}|{a}"]["static"]["far"] - al) for r in runs]
            E1[f"{day}|{a}"] = wilcoxon(e_v2, e_st)
            rows[f"{day}|{a}"] = dict(err_diff=ci(np.array(e_v2) - np.array(e_st)), p=E1[f"{day}|{a}"],
                                      far_v2=ci([r["days"][day][f"{det}|{a}"]["afac_v2"]["far"] for r in runs]),
                                      within_target_plus1=bool(np.mean([r["days"][day][f"{det}|{a}"]["afac_v2"]["far"] for r in runs]) <= al + 1),
                                      rec_minus_oracle=ci([r["days"][day][f"{det}|{a}"]["afac_v2"]["rec"] - r["days"][day][f"{det}|{a}"]["oracle"]["rec"] for r in runs]),
                                      v2_vs_v1_abs_err=ci(np.array(e_v2) - np.array([abs(r["days"][day][f"{det}|{a}"]["afac"]["far"] - al) for r in runs])),
                                      v2_vs_uniform_abs_err=ci(np.array(e_v2) - np.array([abs(r["days"][day][f"{det}|{a}"]["uniform_audit"]["far"] - al) for r in runs])))
    adj = holm(E1)
    for k in rows: rows[k]["p_holm"] = adj[k]
    s1 = sum(1 for k in rows if rows[k]["p_holm"] < 0.05 and rows[k]["err_diff"]["mean"] < 0)
    s2 = sum(1 for k in rows if rows[k]["within_target_plus1"])
    O["endpoints"][det] = dict(rows=rows, S1_count=s1, S1_met=s1 >= 8, S2_count=s2, S2_met=s2 >= 8)
# sensitivity of AFAC-v2 to the anomaly share
SENS = {}
for ds in ["nsl", "unsw", "cic"]:
    fs = sorted(glob.glob(f"{RES}/sens_{ds}_seed*.json"))
    if not fs: continue
    rs = [json.load(open(f)) for f in fs]
    SENS[ds] = {k: {m: ci([r[k].get(m) for r in rs]) for m in ["far", "rec", "rec_unseen", "novel_windows"] if m in rs[0][k]} for k in rs[0]}
    SENS[ds]["n_seeds"] = len(rs)
O["sensitivity"] = SENS
json.dump(O, open(f"{RES}/indep_summary.json", "w"), indent=1)
for det in ["RF", "XGB"]:
    e = O["endpoints"][det]; print(det, "S1", e["S1_count"], "/10 met:", e["S1_met"], "| S2", e["S2_count"], "/10 met:", e["S2_met"])
