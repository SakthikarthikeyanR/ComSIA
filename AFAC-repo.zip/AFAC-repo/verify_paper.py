"""Check the manuscript against the results: every decimal number in the .docx must have been emitted from
results/*.json by the builder (paper_numbers.json) or be on a short list of literals that are quoted from the
earlier version, from published studies, or are method constants. Prints any unexplained number."""
import json, re, sys, zipfile, html
doc = sys.argv[1] if len(sys.argv) > 1 else "IDS_Paper_Refined_v2.docx"
xml = zipfile.ZipFile(doc).read("word/document.xml").decode("utf8")
text = html.unescape(re.sub(r"<[^>]+>", " ", re.sub(r"</w:p>", "\n", xml)))
nums = set(json.load(open("paper_numbers.json")))
literal = {"1.1", "3.1", "3.2", "3.3", "3.4", "4.1", "4.2", "4.3", "4.4"} | {f"5.{i}" for i in range(1, 10)} | {  # constants and quotations that are not experimental results of this paper
    "0.10", "0.5", "0.8", "0.1", "0.05", "2.33", "0.99", "0.002", "0.012", "1.0", "0.88",            # method constants / test facts
    "97.8", "98.6", "95.95", "98.24", "93.4", "87.1", "78.2",                                        # published / earlier-version values
    "1.9.1", "3.4.1", "2.5.3", "3.0.5", "1.18.1", "1.18", "1.9", "3.4", "0.25", "0.75",                                                    # library versions
}
refs_start = text.rfind("References")
body = text[:refs_start] if refs_start > 0 else text
found = re.findall(r"(?<![\w.])(\d+\.\d+)(?![\w])", body)
bad = sorted({f for f in found if f not in nums and f not in literal})
# a number emitted as 'x ± y' is logged as the whole string; accept components of such strings
comp = set()
for s in nums:
    comp.update(re.findall(r"\d+\.\d+", s))
bad = [b for b in bad if b not in comp]
print(f"decimal numbers in body: {len(found)}; unexplained: {len(bad)}")
for b in bad: print("  UNEXPLAINED:", b, "…", body[max(0, body.find(b) - 60): body.find(b) + 20].replace("\n", " "))
sys.exit(1 if bad else 0)
