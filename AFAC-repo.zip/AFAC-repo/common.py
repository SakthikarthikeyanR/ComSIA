"""Shared data loading, preprocessing and metrics for the IDS experiments."""
import os, hashlib, json
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score

DATA = os.environ.get("IDS_DATA", "/home/claude/data")

NSL_COLS = ["duration","protocol_type","service","flag","src_bytes","dst_bytes","land","wrong_fragment","urgent","hot",
 "num_failed_logins","logged_in","num_compromised","root_shell","su_attempted","num_root","num_file_creations","num_shells",
 "num_access_files","num_outbound_cmds","is_host_login","is_guest_login","count","srv_count","serror_rate","srv_serror_rate",
 "rerror_rate","srv_rerror_rate","same_srv_rate","diff_srv_rate","srv_diff_host_rate","dst_host_count","dst_host_srv_count",
 "dst_host_same_srv_rate","dst_host_diff_srv_rate","dst_host_same_src_port_rate","dst_host_srv_diff_host_rate",
 "dst_host_serror_rate","dst_host_srv_serror_rate","dst_host_rerror_rate","dst_host_srv_rerror_rate","label","difficulty"]

FAMILY = {}
for a in ["back","land","neptune","pod","smurf","teardrop","apache2","mailbomb","processtable","udpstorm"]: FAMILY[a]="DoS"
for a in ["ipsweep","nmap","portsweep","satan","mscan","saint"]: FAMILY[a]="Probe"
for a in ["ftp_write","guess_passwd","imap","multihop","phf","spy","warezclient","warezmaster","named","sendmail",
          "snmpgetattack","snmpguess","worm","xlock","xsnoop","httptunnel"]: FAMILY[a]="R2L"
for a in ["buffer_overflow","loadmodule","perl","rootkit","ps","sqlattack","xterm"]: FAMILY[a]="U2R"
FAMILY["normal"]="Normal"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()


class Data:
    """Container: X_tr, y_tr, X_te, y_te (float32 / int8), plus metadata arrays."""


def _encode(frames, cat_cols, num_cols):
    """One-hot categorical columns over the union of categories; z-score numeric columns with train stats (frames[0])."""
    allcat = pd.concat([f[cat_cols] for f in frames])
    cats = {c: sorted(allcat[c].astype(str).unique()) for c in cat_cols}
    tr = frames[0][num_cols].astype(np.float64)
    mu, sd = tr.mean(), tr.std(ddof=0).replace(0, 1.0)
    out, names = [], None
    for f in frames:
        parts = [((f[num_cols].astype(np.float64) - mu) / sd).to_numpy(np.float32)]
        nm = list(num_cols)
        for c in cat_cols:
            v = f[c].astype(str).to_numpy()
            M = np.zeros((len(f), len(cats[c])), np.float32)
            idx = {k: i for i, k in enumerate(cats[c])}
            M[np.arange(len(f)), [idx[x] for x in v]] = 1
            parts.append(M); nm += [f"{c}={k}" for k in cats[c]]
        out.append(np.hstack(parts)); names = nm
    groups = {}  # original feature -> column indices
    for i, n in enumerate(names): groups.setdefault(n.split("=")[0], []).append(i)
    return out, names, groups


def load_nsl():
    d = os.path.join(DATA, "NSL_KDD")
    tr = pd.read_csv(os.path.join(d, "KDDTrain+.txt"), names=NSL_COLS)
    te = pd.read_csv(os.path.join(d, "KDDTest+.txt"), names=NSL_COLS)
    t21 = pd.read_csv(os.path.join(d, "KDDTest-21.txt"), names=NSL_COLS)
    cat = ["protocol_type", "service", "flag"]
    num = [c for c in NSL_COLS[:-2] if c not in cat]
    (Xtr, Xte, X21), names, groups = _encode([tr, te, t21], cat, num)
    D = Data(); D.name = "NSL-KDD"
    D.X_tr, D.X_te, D.X_21 = Xtr, Xte, X21
    D.y_tr = (tr.label != "normal").to_numpy(np.int8); D.y_te = (te.label != "normal").to_numpy(np.int8)
    D.y_21 = (t21.label != "normal").to_numpy(np.int8)
    D.type_tr, D.type_te = tr.label.to_numpy(), te.label.to_numpy()
    D.fam_tr = np.array([FAMILY[a] for a in D.type_tr]); D.fam_te = np.array([FAMILY[a] for a in D.type_te])
    seen = set(D.type_tr)
    D.unseen_te = np.array([(a != "normal") and (a not in seen) for a in D.type_te])
    D.names, D.groups = names, groups
    D.files = {f: sha256(os.path.join(d, f)) for f in ["KDDTrain+.txt", "KDDTest+.txt", "KDDTest-21.txt"]}
    return D


def load_unsw():
    d = os.path.join(DATA, "ML-Projects", "UNSW-Network_Packet_Classification")
    tr = pd.read_csv(os.path.join(d, "UNSW_NB15_training-set.csv"), encoding="utf-8-sig")
    te = pd.read_csv(os.path.join(d, "UNSW_NB15_testing-set.csv"), encoding="utf-8-sig")
    cat = ["proto", "service", "state"]
    num = [c for c in tr.columns if c not in cat + ["id", "attack_cat", "label"]]
    (Xtr, Xte), names, groups = _encode([tr, te], cat, num)
    D = Data(); D.name = "UNSW-NB15"
    D.X_tr, D.X_te = Xtr, Xte
    D.y_tr = tr.label.to_numpy(np.int8); D.y_te = te.label.to_numpy(np.int8)
    D.fam_tr = tr.attack_cat.str.strip().to_numpy(); D.fam_te = te.attack_cat.str.strip().to_numpy()
    D.type_tr, D.type_te = D.fam_tr, D.fam_te
    D.unseen_te = np.zeros(len(te), bool)
    D.names, D.groups = names, groups
    D.files = {f: sha256(os.path.join(d, f)) for f in ["UNSW_NB15_training-set.csv", "UNSW_NB15_testing-set.csv"]}
    return D


def metrics(y, pred, score=None):
    y = np.asarray(y).astype(bool); p = np.asarray(pred).astype(bool)
    tp = int((y & p).sum()); fp = int((~y & p).sum()); tn = int((~y & ~p).sum()); fn = int((y & ~p).sum())
    m = dict(acc=100 * (tp + tn) / len(y), prec=100 * tp / max(tp + fp, 1), rec=100 * tp / max(tp + fn, 1),
             far=100 * fp / max(fp + tn, 1))
    m["f1"] = 2 * m["prec"] * m["rec"] / max(m["prec"] + m["rec"], 1e-12)
    if score is not None:
        m["roc_auc"] = float(roc_auc_score(y, score)); m["pr_auc"] = float(average_precision_score(y, score))
    m.update(tp=tp, fp=fp, tn=tn, fn=fn)
    return m


def threshold_for_far(normal_scores, far):
    """Smallest threshold t such that fraction of normal scores > t is <= far."""
    s = np.sort(np.asarray(normal_scores))
    k = int(np.floor(far * len(s)))
    if k <= 0: return float(np.nextafter(s[-1], np.inf))
    return float(s[len(s) - k - 1]) if len(s) - k - 1 >= 0 else float(s[0])


CIC_TRAIN = ["Monday-WorkingHours.pcap_ISCX.csv", "Wednesday-workingHours.pcap_ISCX.csv"]
CIC_TEST = ["Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv"]


def _read_cic(path):
    df = pd.read_csv(path, encoding="latin-1", low_memory=False)
    df.columns = [c.strip() for c in df.columns]
    return df


def load_cic(n_train=None, seed=0, test_files=None):
    """CIC-IDS2017, temporal protocol: train = Monday + Wednesday, test = Friday-afternoon DDoS (file order = time order).
    Exact duplicate training rows are removed. Numeric features: signed log1p, then z-score with training statistics."""
    d = os.path.join(DATA, "cic2017")
    tr = pd.concat([_read_cic(os.path.join(d, f)) for f in CIC_TRAIN], ignore_index=True)
    test_files = test_files or CIC_TEST
    te = pd.concat([_read_cic(os.path.join(d, f)) for f in test_files], ignore_index=True)
    feats = [c for c in tr.columns if c != "Label"]
    te = te[feats + ["Label"]]
    for f in (tr, te):
        v = f[feats].to_numpy(np.float64); v[~np.isfinite(v)] = np.nan
        f[feats] = np.nan_to_num(v, nan=0.0)
    n_raw = len(tr)
    tr = tr.drop_duplicates().reset_index(drop=True)
    const = [c for c in feats if tr[c].nunique() <= 1]
    feats = [c for c in feats if c not in const]
    def tf(f): v = f[feats].to_numpy(np.float64); return np.sign(v) * np.log1p(np.abs(v))
    A, B = tf(tr), tf(te); mu, sd = A.mean(0), A.std(0); sd[sd == 0] = 1
    D = Data(); D.name = "CIC-IDS2017"
    D.mu, D.sd, D.feats = mu, sd, feats
    D.X_tr = ((A - mu) / sd).astype(np.float32); D.X_te = ((B - mu) / sd).astype(np.float32)
    D.y_tr = (tr.Label.str.strip() != "BENIGN").to_numpy(np.int8); D.y_te = (te.Label.str.strip() != "BENIGN").to_numpy(np.int8)
    D.fam_tr = tr.Label.str.strip().to_numpy(); D.fam_te = te.Label.str.strip().to_numpy()
    D.type_tr, D.type_te = D.fam_tr, D.fam_te
    seen = set(D.type_tr)
    D.unseen_te = np.array([(a != "BENIGN") and (a not in seen) for a in D.type_te])
    D.names = feats; D.groups = {f: [i] for i, f in enumerate(feats)}
    D.n_train_raw, D.n_train_dedup, D.const_dropped = n_raw, len(tr), const
    D.files = {f: sha256(os.path.join(d, f)) for f in CIC_TRAIN + list(test_files)}
    return D


def group_split(X, y, val_frac=0.2, seed=0):
    """80/20 split of the training file in which identical feature vectors are kept on the same side, so that
    validation records are never exact copies of fitting records (duplicate-aware validation)."""
    h = pd.util.hash_pandas_object(pd.DataFrame(X), index=False).to_numpy()
    u, inv = np.unique(h, return_inverse=True)
    rng = np.random.default_rng(seed)
    is_val_group = rng.random(len(u)) < val_frac
    v = is_val_group[inv]
    return np.where(~v)[0], np.where(v)[0]


def cic_test_day(D, fname):
    """Transform one CIC-IDS2017 test file with the training statistics of D (identical to load_cic's test path)."""
    te = _read_cic(os.path.join(DATA, "cic2017", fname))[D.feats + ["Label"]]
    v = te[D.feats].to_numpy(np.float64); v[~np.isfinite(v)] = np.nan; v = np.nan_to_num(v, nan=0.0)
    X = ((np.sign(v) * np.log1p(np.abs(v)) - D.mu) / D.sd).astype(np.float32)
    lab = te.Label.str.strip().to_numpy()
    return X, (lab != "BENIGN").astype(np.int8), lab
