#!/usr/bin/env bash
# Downloads the public mirrors used in the paper into $IDS_DATA (default ./data) and verifies SHA-256 checksums.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
D=${IDS_DATA:-./data}; mkdir -p "$D/NSL_KDD" "$D/ML-Projects/UNSW-Network_Packet_Classification" "$D/cic2017"
get() { curl -fsSL -o "$2" "$1"; }
NSL=https://raw.githubusercontent.com/defcom17/NSL_KDD/master
for f in KDDTrain+.txt KDDTest+.txt KDDTest-21.txt; do get "$NSL/$f" "$D/NSL_KDD/$f"; done
UN=https://raw.githubusercontent.com/Nir-J/ML-Projects/master/UNSW-Network_Packet_Classification
for f in UNSW_NB15_training-set.csv UNSW_NB15_testing-set.csv; do get "$UN/$f" "$D/ML-Projects/UNSW-Network_Packet_Classification/$f"; done
CIC=https://media.githubusercontent.com/media/bibhash074/Machine-Learning/main/datasets
for f in Monday-WorkingHours Tuesday-WorkingHours Wednesday-workingHours Thursday-WorkingHours-Morning-WebAttacks \
         Thursday-WorkingHours-Afternoon-Infilteration Friday-WorkingHours-Morning Friday-WorkingHours-Afternoon-PortScan; do
  get "$CIC/$f.pcap_ISCX.csv" "$D/cic2017/$f.pcap_ISCX.csv"; done
get https://raw.githubusercontent.com/SHUBHAMRAWAT-25/DDOS-attack-detection-using-random-forest-algorithm/main/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv \
    "$D/cic2017/Friday-WorkingHours-Afternoon-DDos.pcap_ISCX.csv"
(cd "$D" && sha256sum -c "$HERE/checksums.sha256")
