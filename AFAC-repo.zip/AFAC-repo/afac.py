"""AFAC: Adaptive False-Alarm Control for a network intrusion detector under changing traffic.

AFAC is a post-hoc layer on top of any scoring detector (here Random Forest or XGBoost) and a normal-only anomaly
detector (Isolation Forest). Traffic is processed in windows. For every window:

 1. Alerts are raised with the current threshold t (and, in novel-attack mode, also by the anomaly branch).
 2. An analyst audits a small labelled sample of the window (budget b = share of window records). The sample is
    stratified: a share h of the budget goes to "suspicious" records (supervised score > s_lo or anomaly score above
    the anomaly detector's 10%-validation-FAR threshold), the rest to the remaining records. Each audited record
    carries a Horvitz-Thompson weight (stratum size / stratum sample size).
 3. From the audited records of the last K windows, the false alarm rate of any candidate rule is estimated as the
    weighted share of audited normal records that the rule flags. The threshold for the next window is the smallest
    t on a grid whose estimated FAR <= alpha (target).
 4. Novel-attack trigger: the weighted detection rate of the supervised detector on audited attacks at its own
    decision point t_ref = 0.5 is compared with the validation detection rate R(t_ref). If it is lower by at least `gap` and a one-sided
    z-test (effective sample size) gives z < -z_crit, the anomaly branch is switched on (OR fusion with the
    Isolation Forest at its alpha/2 validation threshold) and the supervised threshold is re-chosen so that the
    *combined* estimated FAR <= alpha.

Until at least `min_normals` audited normal records are available, the static validation threshold is used.
Audited records are excluded from evaluation by the caller. No unaudited test label is ever used.
"""
import numpy as np

# threshold grid: uniform on [0, 1] plus fine resolution near 0 and 1 (tree ensembles and boosted models
# produce many scores very close to 0 or 1)
GRID = np.unique(np.r_[np.linspace(0.0, 1.0, 401), 1 - np.logspace(-7, -2.5, 46), np.logspace(-7, -2.5, 46)])


def exceed_curve(scores, grid=GRID):
    s = np.sort(np.asarray(scores))
    return 1.0 - np.searchsorted(s, grid, side="right") / max(len(s), 1)


def thr_for_far(normal_scores, far):
    """Smallest threshold t with share of normal scores > t <= far."""
    s = np.sort(np.asarray(normal_scores)); k = int(np.floor(far * len(s)))
    return float(s[len(s) - k - 1]) if k > 0 else float(np.nextafter(s[-1], np.inf))


def weighted_exceed(scores, weights, grid=GRID):
    """Weighted share of scores > t for each t in grid."""
    o = np.argsort(scores); s = scores[o]; w = weights[o]
    tail = np.r_[np.cumsum(w[::-1])[::-1], 0.0]          # tail[i] = sum of w[i:]
    pos = np.searchsorted(s, grid, side="right")
    return tail[pos] / max(w.sum(), 1e-12)


class AFAC:
    def __init__(self, alpha, budget=0.01, share_hi=0.8, window=2000, K=25, s_lo=0.1, min_normals=20,
                 gap=0.10, z_crit=2.326, min_attacks=20, novelty=True, stratified=True, t_ref=0.5, anom_recal=False, anom_share=0.5):
        self.__dict__.update(dict(alpha=alpha, budget=budget, share_hi=share_hi, window=window, K=K, s_lo=s_lo,
                                  min_normals=min_normals, gap=gap, z_crit=z_crit, min_attacks=min_attacks,
                                  novelty=novelty, stratified=stratified, t_ref=t_ref, anom_recal=anom_recal, anom_share=anom_share))

    def fit(self, s_val, a_val, y_val):
        n = y_val == 0
        self.t_static = thr_for_far(s_val[n], self.alpha)
        self.R = exceed_curve(s_val[~n])
        self.tau_hi = thr_for_far(a_val[n], 0.10)         # defines the "suspicious" audit stratum
        self.tau_anom = thr_for_far(a_val[n], self.alpha * self.anom_share)  # anomaly branch threshold (novel-attack mode)
        return self

    def _pick(self, F):
        """Smallest grid threshold with estimated FAR <= alpha. If the target is infeasible below t = 1 (audited
        normals with maximal scores carry more than alpha of the normal weight), alerts are not suppressed
        altogether: the smallest threshold attaining the minimum estimated FAR below 1 is used instead."""
        below = GRID < 1.0
        ok = np.where((F <= self.alpha) & below)[0]
        if len(ok): return float(GRID[ok[0]])
        Fb = F[below]; return float(GRID[below][np.where(Fb <= Fb.min() + 1e-12)[0][0]])

    def _choose(self, s, a, w, y, idx):
        """Choose threshold and mode from audited records idx (labels y known for them only)."""
        nz = idx[y[idx] == 0]; at = idx[y[idx] == 1]
        if len(nz) < self.min_normals:
            return self.t_static, False, dict(mode="warmup", n_norm=len(nz), n_att=len(at))
        F_sup = weighted_exceed(s[nz], w[nz])
        t = self._pick(F_sup)
        novel, z = False, np.nan
        if self.novelty and len(at) >= self.min_attacks:
            # detection of audited attacks at the reference threshold t_ref (the detector's own decision point),
            # where the validation attack profile is most reliable
            ww = w[at]; d = float((ww * (s[at] > self.t_ref)).sum() / ww.sum()); neff = ww.sum() ** 2 / (ww ** 2).sum()
            r = float(np.interp(self.t_ref, GRID, self.R)); se = np.sqrt(max(r * (1 - r), 1e-4) / neff)
            z = (d - r) / se
            novel = (r - d >= self.gap) and (z < -self.z_crit)
        self.tau_cur = self.tau_anom
        if novel and self.anom_recal:
            # revision (v2): the anomaly branch receives half of the false-alarm budget, measured on audited
            # normal traffic instead of taken from validation
            o = np.argsort(-a[nz]); ws = np.cumsum(w[nz][o]) / w[nz].sum()
            k = np.searchsorted(ws, self.alpha * self.anom_share, side="right")
            self.tau_cur = float(a[nz][o][k]) if k < len(o) else float(a[nz].min())
        if novel:
            # combined rule: alert if s > t or a > tau; FAR estimated on audited normals
            anom = a[nz] > self.tau_cur; wn = w[nz]
            base = (wn * anom).sum() / wn.sum()
            F_comb = base + weighted_exceed(s[nz][~anom], wn[~anom]) * (wn[~anom].sum() / wn.sum())
            t = self._pick(F_comb)
        return t, novel, dict(mode="novel" if novel else "calibrated", n_norm=len(nz), n_att=len(at), z=z)

    def run(self, s, a, y, rng):
        """Stream the records in the given order. Returns alerts, evaluation mask (unaudited), per-window log."""
        n = len(s); alerts = np.zeros(n, bool); aud = np.zeros(n, bool); w = np.zeros(n); log = []
        t, novel, info = self.t_static, False, dict(mode="warmup"); self.tau_cur = self.tau_anom
        for st in range(0, n, self.window):
            en = min(st + self.window, n)
            lo = max(0, st - self.K * self.window); idx = np.arange(lo, st); idx = idx[aud[idx]]
            if st > 0:
                t, novel, info = self._choose(s, a, w, y, idx)
            al = s[st:en] > t
            if novel: al |= a[st:en] > self.tau_cur
            alerts[st:en] = al
            log.append(dict(start=st, t=t, novel=bool(novel), **{k: v for k, v in info.items() if k != "z"}))
            # audit after the window
            win = np.arange(st, en); m = int(round(self.budget * len(win)))
            if self.stratified:
                hi = (s[win] > self.s_lo) | (a[win] > self.tau_hi)
                strata = [(win[hi], self.share_hi), (win[~hi], 1 - self.share_hi)]
                # if one stratum is empty, give its share to the other
                if hi.sum() == 0: strata = [(win, 1.0)]
                elif (~hi).sum() == 0: strata = [(win, 1.0)]
            else:
                strata = [(win, 1.0)]
            for grp, share in strata:
                k = min(len(grp), int(round(share * m)))
                if k > 0:
                    pick = rng.choice(grp, k, replace=False); aud[pick] = True; w[pick] = len(grp) / k
        return alerts, ~aud, log


def em_prior_adjust(p, prior_train, iters=200, tol=1e-7):
    """Saerens, Latinne and Decaestecker (2002): EM re-estimation of the class prior from unlabelled posteriors.
    Returns the adjusted posteriors and the estimated attack prior."""
    p = np.clip(p, 1e-6, 1 - 1e-6); pi = prior_train
    for _ in range(iters):
        num = pi / prior_train * p; q = num / (num + (1 - pi) / (1 - prior_train) * (1 - p))
        new = float(q.mean())
        if abs(new - pi) < tol: pi = new; break
        pi = new
    return q, pi
