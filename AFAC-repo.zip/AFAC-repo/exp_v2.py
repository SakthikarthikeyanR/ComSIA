"""Post-hoc revision AFAC-v2 (anomaly-branch threshold recalibrated from audits), added after the
pre-specified CIC-IDS2017 run. Re-creates exactly the same splits, models, stream orders and audit draws as
exp_main.py (same seeds and RNG call sequence) and checks that the reference results are reproduced.
Usage: python exp_v2.py {nsl|unsw|cic} SEED [...]  -> results/v2_<ds>_seed<k>.json
"""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from xgboost import XGBClassifier
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, load_cic, metrics, group_split
from afac import AFAC, thr_for_far
from exp_main import stratified_subsample, drift_order, ALPHAS, BUDGETS, OUT


def run(ds, D, seed):
    rng = np.random.default_rng(seed)
    X, y, fam = D.X_tr, D.y_tr, D.fam_tr
    if ds == "cic":
        sub = stratified_subsample(fam, 300000, rng); X, y, fam = X[sub], y[sub], fam[sub]
    i_fit, i_val = group_split(X, y, 0.2, seed)
    Xf, yf, Xv, yv = X[i_fit], y[i_fit], X[i_val], y[i_val]
    Xt, yt = D.X_te, D.y_te
    det = {"RF": RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=2),
           "XGB": XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                                tree_method="hist", n_jobs=2, random_state=seed, eval_metric="logloss")}
    sv, st = {}, {}
    for k, m in det.items():
        m.fit(Xf, yf); sv[k] = m.predict_proba(Xv)[:, 1]; st[k] = m.predict_proba(Xt)[:, 1]
    Xn = Xf[yf == 0]
    iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(Xn)
    av, at = -iso.score_samples(Xv), -iso.score_samples(Xt)
    rng.choice(len(Xn), min(len(Xn), 60000), replace=False)          # same RNG consumption as exp_main (AE sample)
    orders = {"shuffled": rng.permutation(len(yt))}
    if ds == "cic": orders = {"temporal": np.arange(len(yt))}
    else: orders["prevalence_drift"] = drift_order(yt, rng)
    ref = json.load(open(os.path.join(OUT, f"main_{ds}_seed{seed}.json")))
    extra = {}
    if D.unseen_te.any(): extra["rec_unseen"] = D.unseen_te
    R = {}
    for d in det:
        for oname, o in orders.items():
            s, a_, yy = st[d][o], at[o], yt[o]; un = D.unseen_te[o]
            half = np.arange(len(yy)) >= len(yy) // 2
            for alpha in ALPHAS:
                key = f"{d}|{oname}|{alpha}"; res = {}
                # reproduction check against exp_main
                ts = thr_for_far(sv[d][yv == 0], alpha)
                chk = metrics(yy, s > ts)["far"]; res["check_static_far"] = [chk, ref["far_control"][key]["static"]["far"]]
                A0 = AFAC(alpha, budget=0.01).fit(sv[d], av, yv)
                al0, m0, _ = A0.run(s, a_, yy, np.random.default_rng(1000 + seed))
                res["check_afac_far"] = [metrics(yy[m0], al0[m0])["far"], ref["far_control"][key]["afac@0.01"]["far"]]
                for b in BUDGETS:
                    A = AFAC(alpha, budget=b, anom_recal=True).fit(sv[d], av, yv)
                    al, mask, log = A.run(s, a_, yy, np.random.default_rng(1000 + seed))
                    r = metrics(yy[mask], al[mask])
                    if un.any(): r["rec_unseen"] = float(100 * al[mask & un].mean())
                    m2 = mask & half; r["2ndhalf"] = metrics(yy[m2], al[m2])
                    r["labels_used"] = int((~mask).sum()); r["label_share"] = float((~mask).mean())
                    r["novel_windows"] = int(sum(l["novel"] for l in log)); r["windows"] = len(log)
                    res[f"afac_v2@{b}"] = r
                    if b == 0.01:
                        W = A.window; tr = []
                        for st0 in range(0, len(yy), W):
                            sl = slice(st0, st0 + W); mm = mask[sl]; yw = yy[sl][mm]; aw = al[sl][mm]
                            tr.append(dict(start=st0, attack_share=float(yy[sl].mean()),
                                           far=float(100 * aw[yw == 0].mean()) if (yw == 0).any() else None,
                                           rec=float(100 * aw[yw == 1].mean()) if (yw == 1).any() else None,
                                           far_static=float(100 * (s[sl][yy[sl] == 0] > ts).mean()) if (yy[sl] == 0).any() else None,
                                           novel=bool(log[st0 // W]["novel"]), t=float(log[st0 // W]["t"])))
                        res["v2_windows"] = tr
                R[key] = res
    json.dump(R, open(os.path.join(OUT, f"v2_{ds}_seed{seed}.json"), "w"))


if __name__ == "__main__":
    ds = sys.argv[1]; D = {"nsl": load_nsl, "unsw": load_unsw, "cic": load_cic}[ds]()
    for s in map(int, sys.argv[2:]):
        t = time.time(); run(ds, D, s); print(ds, s, round(time.time() - t), "s", flush=True)
