"""Frozen independent validation on five unseen CIC-IDS2017 days (see PROTOCOL_independent_validation.md).
Usage: python exp_independent.py SEED [SEED ...]  -> results/indep_seed<k>.json
Training identical to exp_main.py (cic); each test day is a separate stream in file (time) order."""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from xgboost import XGBClassifier
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_cic, metrics, group_split
from afac import AFAC, thr_for_far, exceed_curve, GRID
from exp_main import stratified_subsample, OUT

DAYS = {"Tuesday": "Tuesday-WorkingHours.pcap_ISCX.csv",
        "Thursday-AM": "Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv",
        "Thursday-PM": "Thursday-WorkingHours-Afternoon-Infilteration.pcap_ISCX.csv",
        "Friday-AM": "Friday-WorkingHours-Morning.pcap_ISCX.csv",
        "Friday-PortScan": "Friday-WorkingHours-Afternoon-PortScan.pcap_ISCX.csv"}
ALPHAS = [0.01, 0.05]


def main(seeds):
    # memory-safe loading (post-freeze fix, see protocol_freeze.json): training once, each test day separately
    from common import cic_test_day
    D = load_cic()                                    # training part identical; default test file is ignored
    TE = {day: cic_test_day(D, f) for day, f in DAYS.items()}
    D.X_te = D.y_te = None
    D.files.update({f: __import__("common").sha256(os.path.join(os.environ.get("IDS_DATA", "/home/claude/data"), "cic2017", f)) for f in DAYS.values()})
    for seed in seeds:
        t0 = time.time(); rng = np.random.default_rng(seed)
        sub = stratified_subsample(D.fam_tr, 300000, rng); X, y = D.X_tr[sub], D.y_tr[sub]
        i_fit, i_val = group_split(X, y, 0.2, seed)
        Xf, yf, Xv, yv = X[i_fit], y[i_fit], X[i_val], y[i_val]
        det = {"RF": RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=2),
               "XGB": XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8,
                                    tree_method="hist", n_jobs=2, random_state=seed, eval_metric="logloss")}
        sv, st = {}, {}
        for k, m in det.items():
            m.fit(Xf, yf); sv[k] = m.predict_proba(Xv)[:, 1]; st[k] = {day: m.predict_proba(TE[day][0])[:, 1] for day in DAYS}
        iso = IsolationForest(n_estimators=200, random_state=seed, n_jobs=2).fit(Xf[yf == 0])
        av = -iso.score_samples(Xv); at = {day: -iso.score_samples(TE[day][0]) for day in DAYS}
        R = dict(seed=seed, files=D.files, days={})
        for di, (day, fname) in enumerate(DAYS.items()):
            yy = TE[day][1]; a_ = at[day]
            out = dict(n=int(len(yy)), n_attack=int(yy.sum()), attack_types=sorted(set(TE[day][2]) - {"BENIGN"}))
            tau = thr_for_far(av[yv == 0], 0.01); out["IF@1%"] = metrics(yy, a_ > tau)
            for d in det:
                s = st[d][day]
                out[f"{d}|default"] = metrics(yy, s > 0.5, s if 0 < yy.sum() < len(yy) else None)
                for alpha in ALPHAS:
                    key = f"{d}|{alpha}"; res = {}
                    ts = thr_for_far(sv[d][yv == 0], alpha); res["static"] = metrics(yy, s > ts)
                    Ft = exceed_curve(s[yy == 0]); i = np.where((Ft <= alpha) & (GRID < 1))[0]
                    to = float(GRID[i[0]]) if len(i) else float(GRID[GRID < 1][-1]); res["oracle"] = metrics(yy, s > to)
                    for name, kw in [("uniform_audit", dict(novelty=False, stratified=False)), ("afac_nonovelty", dict(novelty=False)),
                                     ("afac", {}), ("afac_v2", dict(anom_recal=True))]:
                        A = AFAC(alpha, budget=0.01, **kw).fit(sv[d], av, yv)
                        al, mask, log = A.run(s, a_, yy, np.random.default_rng(1000 + seed))
                        r = metrics(yy[mask], al[mask]); r["novel_windows"] = int(sum(l["novel"] for l in log)); r["windows"] = len(log)
                        r["labels_used"] = int((~mask).sum()); res[name] = r
                    out[key] = res
            R["days"][day] = out
        json.dump(R, open(os.path.join(OUT, f"indep_seed{seed}.json"), "w"), default=lambda x: float(x) if isinstance(x, (np.floating, np.integer)) else str(x))
        print("seed", seed, round(time.time() - t0), "s", flush=True)


if __name__ == "__main__":
    main([int(s) for s in sys.argv[1:]])
