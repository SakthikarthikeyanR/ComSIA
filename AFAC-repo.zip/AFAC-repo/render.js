// Render paper spec (JSON) into a .docx. Usage: node render.js spec.json out.docx
const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, ImageRun, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, Footer, PageNumber, LevelFormat, VerticalAlign, TabStopType,
} = require("docx");

const spec = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const FONT = "Times New Roman";
const PAGE_W = 11906, MARGIN = spec.margin || 1440, CONTENT_W = PAGE_W - 2 * MARGIN; // A4
const BS = spec.fontSize || 22, LINE = spec.line || 276;

// inline markup: **bold**, *italic*, ^sup^, ~sub~
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|\^[^^]+\^|~[^~]+~)/g;
  let last = 0, m;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, ...base }));
    else if (t.startsWith("*")) out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, ...base }));
    else if (t.startsWith("^")) out.push(new TextRun({ text: t.slice(1, -1), superScript: true, font: FONT, ...base }));
    else out.push(new TextRun({ text: t.slice(1, -1), subScript: true, font: FONT, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, ...base }));
  return out;
}

const thin = { style: BorderStyle.SINGLE, size: 4, color: "000000" };
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };

function table(b) {
  const ncol = b.header.length;
  const widths = b.widths ? b.widths.map(w => Math.round(w * CONTENT_W / b.widths.reduce((a, c) => a + c, 0))) :
    Array(ncol).fill(Math.floor(CONTENT_W / ncol));
  const diff = CONTENT_W - widths.reduce((a, c) => a + c, 0); widths[0] += diff;
  const sz = b.size || 17;
  const mkRow = (cells, isHeader, isLast, shade) => new TableRow({
    tableHeader: isHeader,
    children: cells.map((c, i) => new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      margins: { top: 20, bottom: 20, left: 50, right: 50 },
      verticalAlign: VerticalAlign.CENTER,
      shading: shade ? { fill: shade, type: ShadingType.CLEAR, color: "auto" } : undefined,
      borders: { top: isHeader ? thin : none, bottom: (isHeader || isLast) ? thin : none, left: none, right: none },
      children: [new Paragraph({
        alignment: i === 0 ? AlignmentType.LEFT : AlignmentType.CENTER, spacing: { before: 0, after: 0 },
        children: runs(String(c), { size: sz, bold: isHeader })
      })],
    })),
  });
  const rows = [mkRow(b.header, true, false, "F2F2F2")];
  b.rows.forEach((r, i) => {
    const isGroup = r.length === 1;
    if (isGroup) {
      rows.push(new TableRow({ children: [new TableCell({
        columnSpan: ncol, width: { size: CONTENT_W, type: WidthType.DXA },
        margins: { top: 40, bottom: 20, left: 70, right: 70 },
        borders: { top: none, bottom: none, left: none, right: none },
        children: [new Paragraph({ spacing: { before: 0, after: 0 }, children: runs(String(r[0]), { size: sz, italics: true }) })]
      })] }));
    } else rows.push(mkRow(r, false, i === b.rows.length - 1, (b.highlight || []).includes(i) ? "FFF4E5" : null));
  });
  return new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: widths, rows });
}

const children = [];
for (const b of spec.blocks) {
  if (b.type === "title") children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: runs(b.text, { size: BS + 8, bold: true }) }));
  else if (b.type === "center") children.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: runs(b.text, { size: b.size || BS }) }));
  else if (b.type === "h1") children.push(new Paragraph({ heading: HeadingLevel.HEADING_1, keepNext: true, spacing: { before: 200, after: 80 }, children: runs(b.text, { size: BS + 4, bold: true, color: "000000" }) }));
  else if (b.type === "h2") children.push(new Paragraph({ heading: HeadingLevel.HEADING_2, keepNext: true, spacing: { before: 140, after: 60 }, children: runs(b.text, { size: BS + 1, bold: true, italics: true, color: "000000" }) }));
  else if (b.type === "p") children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 80, line: LINE }, children: runs(b.text, { size: BS }) }));
  else if (b.type === "abstract") children.push(new Paragraph({ alignment: AlignmentType.JUSTIFIED, spacing: { after: 120, line: 264 }, indent: { left: 360, right: 360 }, children: runs(b.text, { size: BS - 2 }) }));
  else if (b.type === "bullet") children.push(new Paragraph({ numbering: { reference: "bullets", level: 0 }, alignment: AlignmentType.JUSTIFIED, spacing: { after: 40, line: LINE }, children: runs(b.text, { size: BS }) }));
  else if (b.type === "num") children.push(new Paragraph({ numbering: { reference: b.ref || "steps", level: 0 }, alignment: AlignmentType.JUSTIFIED, spacing: { after: 40, line: LINE }, children: runs(b.text, { size: BS }) }));
  else if (b.type === "eq") children.push(new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 60, after: 120 },
      tabStops: [{ type: TabStopType.CENTER, position: Math.round(CONTENT_W / 2) }, { type: TabStopType.RIGHT, position: CONTENT_W }],
      children: [new TextRun({ text: "\t", font: FONT, size: BS }), ...runs(b.text, { size: BS }), new TextRun({ text: "\t" + (b.label || ""), font: FONT, size: BS })] }));
  else if (b.type === "caption") children.push(new Paragraph({ alignment: b.align === "left" ? AlignmentType.LEFT : AlignmentType.CENTER, keepNext: !!b.keepNext, spacing: { before: 80, after: 120 }, children: runs(b.text, { size: BS - 3 }) }));
  else if (b.type === "table") { children.push(table(b)); children.push(new Paragraph({ spacing: { after: 60 }, children: b.note ? runs(b.note, { size: 16, italics: false }) : [] })); }
  else if (b.type === "figure") {
    const img = fs.readFileSync(b.path);
    const w = b.width || 600; const h = Math.round(w * b.ratio);
    children.push(new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 0 },
      children: [new ImageRun({ type: "png", data: img, transformation: { width: w, height: h }, altText: { title: b.alt || "Figure", description: b.alt || "Figure", name: path.basename(b.path) } })] }));
  }
  else if (b.type === "ref") children.push(new Paragraph({ alignment: AlignmentType.LEFT, spacing: { after: 30, line: 240 }, indent: { left: 480, hanging: 480 },
      tabStops: [{ type: TabStopType.LEFT, position: 480 }], children: runs(b.text, { size: BS - 4 }) }));
  else throw new Error("unknown block " + b.type);
}

const doc = new Document({
  creator: spec.creator || "", title: spec.doc_title || "",
  styles: {
    default: { document: { run: { font: FONT, size: BS } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, font: FONT, color: "000000" }, paragraph: { spacing: { before: 280, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 23, bold: true, italics: true, font: FONT, color: "000000" }, paragraph: { spacing: { before: 200, after: 100 }, outlineLevel: 1 } },
    ],
  },
  numbering: { config: [
    { reference: "bullets", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 270 } } } }] },
    { reference: "steps", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
    { reference: "steps2", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540, hanging: 300 } } } }] },
  ] },
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: 16838 }, margin: { top: MARGIN, right: MARGIN, bottom: MARGIN, left: MARGIN } } },
    footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 18 })] })] }) },
    children,
  }],
});
Packer.toBuffer(doc).then(buf => { fs.writeFileSync(process.argv[3], buf); console.log("written", process.argv[3]); });
