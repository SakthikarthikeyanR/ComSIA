"""Leakage-controlled feature selection (grouped permutation importance) vs. leaky test-based selection.
Usage: python exp_fs.py {nsl|unsw}   -> results/fs_<ds>.json
"""
import sys, os, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import load_nsl, load_unsw, metrics, group_split

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


def grouped_perm_importance(model, X, y, groups, rng, repeats=5):
    base = (model.predict(X) == y).mean(); imp = {}
    for g, cols in groups.items():
        drops = []
        for _ in range(repeats):
            Xp = X.copy(); p = rng.permutation(len(X)); Xp[:, cols] = X[p][:, cols]
            drops.append(base - (model.predict(Xp) == y).mean())
        imp[g] = float(np.mean(drops))
    return dict(sorted(imp.items(), key=lambda kv: -kv[1]))


def main(ds):
    D = {"nsl": load_nsl, "unsw": load_unsw}[ds]()
    i_fit, i_val = group_split(D.X_tr, D.y_tr, 0.2, 0)
    rf = RandomForestClassifier(100, random_state=0, n_jobs=2).fit(D.X_tr[i_fit], D.y_tr[i_fit])
    imp_val = grouped_perm_importance(rf, D.X_tr[i_val], D.y_tr[i_val], D.groups, np.random.default_rng(0))
    imp_test = grouped_perm_importance(rf, D.X_te, D.y_te, D.groups, np.random.default_rng(0))
    R = dict(dataset=D.name, imp_val=imp_val, imp_test=imp_test, runs={})
    ks = [5, 10, 20, None]
    configs = [("all", None, None)] + [(f"val_top{k}", imp_val, k) for k in ks[:-1]] + [(f"test_top{k}", imp_test, k) for k in [5, 10]]
    for name, imp, k in configs:
        feats = list(D.groups) if imp is None else list(imp)[:k]
        cols = [c for f in feats for c in D.groups[f]]
        rows = []
        for seed in range(10):
            fi, _ = group_split(D.X_tr, D.y_tr, 0.2, seed)
            t = time.time()
            m = RandomForestClassifier(100, random_state=seed, n_jobs=2).fit(D.X_tr[fi][:, cols], D.y_tr[fi])
            el = time.time() - t
            p = m.predict_proba(D.X_te[:, cols])[:, 1]
            r = metrics(D.y_te, p > 0.5, p); r["time"] = el
            if ds == "nsl":
                p21 = m.predict_proba(D.X_21[:, cols])[:, 1]; r["acc21"] = metrics(D.y_21, p21 > 0.5)["acc"]
            rows.append(r)
        R["runs"][name] = dict(features=feats, per_seed=rows)
        print(ds, name, round(np.mean([r["acc"] for r in rows]), 2), flush=True)
    json.dump(R, open(os.path.join(OUT, f"fs_{ds}.json"), "w"))


if __name__ == "__main__":
    main(sys.argv[1])
