"""Aggregate per-seed JSON results into results/summary.json (means, 95% CIs, statistical tests)."""
import os, json, glob
import numpy as np
from scipy import stats

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
DS = {"nsl": "NSL-KDD", "unsw": "UNSW-NB15", "cic": "CIC-IDS2017"}


def ci(x):
    x = np.asarray([v for v in x if v is not None], float)
    if len(x) == 0: return None
    m = float(x.mean())
    h = float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / np.sqrt(len(x))) if len(x) > 1 else 0.0
    return dict(mean=m, ci=h, n=int(len(x)), sd=float(x.std(ddof=1)) if len(x) > 1 else 0.0)


def wilcoxon(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if np.allclose(a, b): return 1.0
    return float(stats.wilcoxon(a, b, zero_method="pratt", alternative="two-sided").pvalue)


def holm(pvals):
    keys = list(pvals); p = np.array([pvals[k] for k in keys]); o = np.argsort(p); m = len(p)
    adj = np.empty(m); run = 0.0
    for r, i in enumerate(o):
        run = max(run, min(1.0, (m - r) * p[i])); adj[i] = run
    return {k: float(a) for k, a in zip(keys, adj)}


def load(pattern):
    return [json.load(open(f)) for f in sorted(glob.glob(os.path.join(RES, pattern)))]


def main():
    S = {}
    tests = {}
    for ds, name in DS.items():
        runs = load(f"main_{ds}_seed*.json")
        if not runs: continue
        v2 = {r["seed"]: None for r in runs}
        for r in runs:
            f = os.path.join(RES, f"v2_{ds}_seed{r['seed']}.json")
            v2[r["seed"]] = json.load(open(f)) if os.path.exists(f) else None
        has_v2 = all(v is not None for v in v2.values())
        if has_v2:
            for r in runs:
                for key, res in v2[r["seed"]].items():
                    for meth, v in res.items():
                        if meth.startswith("afac_v2@"): r["far_control"][key][meth] = v
                    r["far_control"][key]["v2_windows"] = res["v2_windows"]
        T = S[name] = dict(n_seeds=len(runs), meta={}, baseline={}, far_control={})
        r0 = runs[0]
        T["meta"] = {k: ci([r[k] for r in runs]) for k in ["n_fit", "n_val", "val_attack_share", "fit_attack_share", "test_attack_share"]}
        T["meta"]["files"] = r0["files"]
        # baselines
        for model in r0["baseline"]:
            keys = [k for k, v in r0["baseline"][model].items() if isinstance(v, (int, float)) or v is None]
            T["baseline"][model] = {k: ci([r["baseline"][model].get(k) for r in runs]) for k in keys}
            for sub in ["val", "test21"]:
                if sub in r0["baseline"][model]:
                    T["baseline"][model][sub] = {k: ci([r["baseline"][model][sub][k] for r in runs])
                                                 for k in ["acc", "rec", "far", "f1", "pr_auc", "roc_auc"] if k in r0["baseline"][model][sub]}
        T["timing_s"] = {k: ci([r["timing_s"][k] for r in runs]) for k in r0["timing_s"]}
        # far control
        for key, res0 in r0["far_control"].items():
            det, order, alpha = key.split("|"); alpha = float(alpha)
            out = T["far_control"][key] = {}
            for meth, v0 in res0.items():
                if not isinstance(v0, dict): continue
                vals = {}
                for k, v in v0.items():
                    if isinstance(v, (int, float)) or v is None:
                        vals[k] = ci([r["far_control"][key][meth].get(k) for r in runs])
                    elif k == "2ndhalf":
                        vals["2ndhalf"] = {kk: ci([r["far_control"][key][meth]["2ndhalf"][kk] for r in runs]) for kk in ["far", "rec", "prec", "f1"]}
                vals["far_abs_err"] = ci([abs(r["far_control"][key][meth]["far"] - 100 * alpha) for r in runs])
                out[meth] = vals
            # paired tests across seeds
            def col(meth, k): return [r["far_control"][key][meth][k] for r in runs]
            def err(meth): return [abs(r["far_control"][key][meth]["far"] - 100 * alpha) for r in runs]
            if len(runs) >= 5:
                pairs = [("afac@0.01", c) for c in ["static", "uniform_audit@0.01", "afac_nonovelty@0.01", "em_prior"]]
                if "afac_v2@0.01" in res0 or has_v2:
                    pairs += [("afac_v2@0.01", c) for c in ["static", "uniform_audit@0.01", "afac_nonovelty@0.01", "afac@0.01"]]
                for A_, comp in pairs:
                    tests[f"{name}|{key}|{A_} vs {comp}|abs_far_err"] = wilcoxon(err(A_), err(comp))
                    for mm in ["rec", "far", "f1", "prec"]:
                        tests[f"{name}|{key}|{A_} vs {comp}|{mm}"] = wilcoxon(col(A_, mm), col(comp, mm))
        # baseline paired tests: XGB vs RF etc. on PR-AUC and FAR
        if len(runs) >= 5:
            for a, b in [("XGB", "RF"), ("RF+IF hybrid", "RF"), ("MLP", "RF")]:
                for k in ["far", "rec", "f1", "pr_auc"]:
                    if r0["baseline"][a].get(k) is None or r0["baseline"][b].get(k) is None: continue
                    tests[f"{name}|baseline|{a} vs {b}|{k}"] = wilcoxon([r["baseline"][a][k] for r in runs], [r["baseline"][b][k] for r in runs])
    # Holm correction within the main family of AFAC-vs-static tests (all datasets, detectors, orders, alphas, metrics)
    fam = {k: v for k, v in tests.items() if "|afac" in k}
    S["tests_raw"] = tests
    S["tests_holm"] = holm(fam) if fam else {}
    # robustness
    for exp in ["imbalance", "lofo"]:
        for ds, name in DS.items():
            runs = load(f"robust_{exp}_{ds}_seed*.json")
            if not runs: continue
            O = S.setdefault("robust_" + exp, {}).setdefault(name, {"n_seeds": len(runs)})
            for cond, v0 in runs[0].items():
                O[cond] = {}
                for meth, m0 in v0.items():
                    if isinstance(m0, dict):
                        O[cond][meth] = {k: ci([r[cond][meth][k] for r in runs]) for k, x in m0.items() if isinstance(x, (int, float)) or x is None}
                    else:
                        O[cond][meth] = ci([r[cond][meth] for r in runs])
    # feature selection
    for ds, name in DS.items():
        f = os.path.join(RES, f"fs_{ds}.json")
        if not os.path.exists(f): continue
        R = json.load(open(f)); O = S.setdefault("feature_selection", {})[name] = dict(imp_val=R["imp_val"], imp_test=R["imp_test"], runs={})
        for cfg, v in R["runs"].items():
            O["runs"][cfg] = dict(features=v["features"], **{k: ci([r[k] for r in v["per_seed"]]) for k in v["per_seed"][0]
                                                           if k not in ("tp", "fp", "tn", "fn")})
    json.dump(S, open(os.path.join(RES, "summary.json"), "w"), indent=1)
    print("summary written:", list(S))


if __name__ == "__main__":
    main()


def families():
    """Pre-stated hypothesis families (6 tests each: 3 datasets x 2 targets, main stream), Holm within family.
    Paired difference = A - B per seed; 95% CI by t-distribution."""
    S = json.load(open(os.path.join(RES, "summary.json")))
    runs = {name: load(f"main_{ds}_seed*.json") for ds, name in DS.items()}
    v2 = {name: {r["seed"]: json.load(open(os.path.join(RES, f"v2_{ds}_seed{r['seed']}.json"))) for r in runs[name]} for ds, name in DS.items()}
    def get(name, key, meth, k, alpha):
        out = []
        for r in runs[name]:
            v = v2[name][r["seed"]][key][meth] if meth.startswith("afac_v2") else r["far_control"][key][meth]
            out.append(abs(v["far"] - 100 * alpha) if k == "abs_far_err" else v[k])
        return np.array(out)
    F = {}
    for det in ["RF", "XGB"]:
        specs = {"H1 AFAC-v2 vs static: |FAR - target|": ("afac_v2@0.01", "static", "abs_far_err"),
                 "H2 AFAC-v2 vs static: recall": ("afac_v2@0.01", "static", "rec"),
                 "H3 AFAC-v2 vs uniform audit: |FAR - target|": ("afac_v2@0.01", "uniform_audit@0.01", "abs_far_err"),
                 "H4 AFAC-v2 vs AFAC without novelty trigger: recall": ("afac_v2@0.01", "afac_nonovelty@0.01", "rec")}
        for fam, (A, B, k) in specs.items():
            rows = {}
            for name, order in [("NSL-KDD", "shuffled"), ("UNSW-NB15", "shuffled"), ("CIC-IDS2017", "temporal")]:
                for alpha in [0.01, 0.05]:
                    key = f"{det}|{order}|{alpha}"
                    a, b = get(name, key, A, k, alpha), get(name, key, B, k, alpha)
                    rows[f"{name}|{alpha}"] = dict(diff=ci(a - b), p=wilcoxon(a, b))
            adj = holm({kk: v["p"] for kk, v in rows.items()})
            for kk in rows: rows[kk]["p_holm"] = adj[kk]
            F[f"{det}|{fam}"] = rows
    S["families"] = F
    json.dump(S, open(os.path.join(RES, "summary.json"), "w"), indent=1)


if __name__ == "__main__":
    families()
